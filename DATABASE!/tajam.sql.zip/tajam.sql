-- phpMyAdmin SQL Dump
-- version 4.7.2
-- https://www.phpmyadmin.net/
--
-- Host: localhost:8889
-- Generation Time: Apr 11, 2019 at 02:02 PM
-- Server version: 5.6.35
-- PHP Version: 7.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `tajam`
--

-- --------------------------------------------------------

--
-- Table structure for table `wp_commentmeta`
--

CREATE TABLE `wp_commentmeta` (
  `meta_id` bigint(20) UNSIGNED NOT NULL,
  `comment_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- Table structure for table `wp_comments`
--

CREATE TABLE `wp_comments` (
  `comment_ID` bigint(20) UNSIGNED NOT NULL,
  `comment_post_ID` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `comment_author` tinytext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `comment_author_email` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT '0',
  `comment_approved` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_type` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_parent` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `user_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Dumping data for table `wp_comments`
--

INSERT INTO `wp_comments` (`comment_ID`, `comment_post_ID`, `comment_author`, `comment_author_email`, `comment_author_url`, `comment_author_IP`, `comment_date`, `comment_date_gmt`, `comment_content`, `comment_karma`, `comment_approved`, `comment_agent`, `comment_type`, `comment_parent`, `user_id`) VALUES
(1, 1, 'Автор комментария', 'wapuu@wordpress.example', 'https://wordpress.org/', '', '2019-04-09 11:42:50', '2019-04-09 08:42:50', 'Привет! Это комментарий.\nЧтобы начать модерировать, редактировать и удалять комментарии, перейдите на экран «Комментарии» в консоли.\nАватары авторов комментариев загружаются с сервиса <a href=\"https://ru.gravatar.com\">Gravatar</a>.', 0, '1', '', '', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `wp_links`
--

CREATE TABLE `wp_links` (
  `link_id` bigint(20) UNSIGNED NOT NULL,
  `link_url` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_name` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_image` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_target` varchar(25) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_description` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_visible` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'Y',
  `link_owner` bigint(20) UNSIGNED NOT NULL DEFAULT '1',
  `link_rating` int(11) NOT NULL DEFAULT '0',
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_notes` mediumtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `link_rss` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- Table structure for table `wp_options`
--

CREATE TABLE `wp_options` (
  `option_id` bigint(20) UNSIGNED NOT NULL,
  `option_name` varchar(191) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `option_value` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `autoload` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'yes'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Dumping data for table `wp_options`
--

INSERT INTO `wp_options` (`option_id`, `option_name`, `option_value`, `autoload`) VALUES
(1, 'siteurl', 'http://localhost:8888/tajam', 'yes'),
(2, 'home', 'http://localhost:8888/tajam', 'yes'),
(3, 'blogname', 'Tajam', 'yes'),
(4, 'blogdescription', 'Ещё один сайт на WordPress', 'yes'),
(5, 'users_can_register', '0', 'yes'),
(6, 'admin_email', 'farik4098@gmail.com', 'yes'),
(7, 'start_of_week', '1', 'yes'),
(8, 'use_balanceTags', '0', 'yes'),
(9, 'use_smilies', '1', 'yes'),
(10, 'require_name_email', '1', 'yes'),
(11, 'comments_notify', '1', 'yes'),
(12, 'posts_per_rss', '10', 'yes'),
(13, 'rss_use_excerpt', '0', 'yes'),
(14, 'mailserver_url', 'mail.example.com', 'yes'),
(15, 'mailserver_login', 'login@example.com', 'yes'),
(16, 'mailserver_pass', 'password', 'yes'),
(17, 'mailserver_port', '110', 'yes'),
(18, 'default_category', '1', 'yes'),
(19, 'default_comment_status', 'open', 'yes'),
(20, 'default_ping_status', 'open', 'yes'),
(21, 'default_pingback_flag', '0', 'yes'),
(22, 'posts_per_page', '10', 'yes'),
(23, 'date_format', 'd.m.Y', 'yes'),
(24, 'time_format', 'H:i', 'yes'),
(25, 'links_updated_date_format', 'd.m.Y H:i', 'yes'),
(26, 'comment_moderation', '0', 'yes'),
(27, 'moderation_notify', '1', 'yes'),
(28, 'permalink_structure', '/%year%/%monthnum%/%day%/%postname%/', 'yes'),
(29, 'rewrite_rules', 'a:90:{s:11:\"^wp-json/?$\";s:22:\"index.php?rest_route=/\";s:14:\"^wp-json/(.*)?\";s:33:\"index.php?rest_route=/$matches[1]\";s:21:\"^index.php/wp-json/?$\";s:22:\"index.php?rest_route=/\";s:24:\"^index.php/wp-json/(.*)?\";s:33:\"index.php?rest_route=/$matches[1]\";s:47:\"category/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:52:\"index.php?category_name=$matches[1]&feed=$matches[2]\";s:42:\"category/(.+?)/(feed|rdf|rss|rss2|atom)/?$\";s:52:\"index.php?category_name=$matches[1]&feed=$matches[2]\";s:23:\"category/(.+?)/embed/?$\";s:46:\"index.php?category_name=$matches[1]&embed=true\";s:35:\"category/(.+?)/page/?([0-9]{1,})/?$\";s:53:\"index.php?category_name=$matches[1]&paged=$matches[2]\";s:17:\"category/(.+?)/?$\";s:35:\"index.php?category_name=$matches[1]\";s:44:\"tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?tag=$matches[1]&feed=$matches[2]\";s:39:\"tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?tag=$matches[1]&feed=$matches[2]\";s:20:\"tag/([^/]+)/embed/?$\";s:36:\"index.php?tag=$matches[1]&embed=true\";s:32:\"tag/([^/]+)/page/?([0-9]{1,})/?$\";s:43:\"index.php?tag=$matches[1]&paged=$matches[2]\";s:14:\"tag/([^/]+)/?$\";s:25:\"index.php?tag=$matches[1]\";s:45:\"type/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?post_format=$matches[1]&feed=$matches[2]\";s:40:\"type/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?post_format=$matches[1]&feed=$matches[2]\";s:21:\"type/([^/]+)/embed/?$\";s:44:\"index.php?post_format=$matches[1]&embed=true\";s:33:\"type/([^/]+)/page/?([0-9]{1,})/?$\";s:51:\"index.php?post_format=$matches[1]&paged=$matches[2]\";s:15:\"type/([^/]+)/?$\";s:33:\"index.php?post_format=$matches[1]\";s:48:\".*wp-(atom|rdf|rss|rss2|feed|commentsrss2)\\.php$\";s:18:\"index.php?feed=old\";s:20:\".*wp-app\\.php(/.*)?$\";s:19:\"index.php?error=403\";s:18:\".*wp-register.php$\";s:23:\"index.php?register=true\";s:32:\"feed/(feed|rdf|rss|rss2|atom)/?$\";s:27:\"index.php?&feed=$matches[1]\";s:27:\"(feed|rdf|rss|rss2|atom)/?$\";s:27:\"index.php?&feed=$matches[1]\";s:8:\"embed/?$\";s:21:\"index.php?&embed=true\";s:20:\"page/?([0-9]{1,})/?$\";s:28:\"index.php?&paged=$matches[1]\";s:27:\"comment-page-([0-9]{1,})/?$\";s:38:\"index.php?&page_id=6&cpage=$matches[1]\";s:41:\"comments/feed/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?&feed=$matches[1]&withcomments=1\";s:36:\"comments/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?&feed=$matches[1]&withcomments=1\";s:17:\"comments/embed/?$\";s:21:\"index.php?&embed=true\";s:44:\"search/(.+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:40:\"index.php?s=$matches[1]&feed=$matches[2]\";s:39:\"search/(.+)/(feed|rdf|rss|rss2|atom)/?$\";s:40:\"index.php?s=$matches[1]&feed=$matches[2]\";s:20:\"search/(.+)/embed/?$\";s:34:\"index.php?s=$matches[1]&embed=true\";s:32:\"search/(.+)/page/?([0-9]{1,})/?$\";s:41:\"index.php?s=$matches[1]&paged=$matches[2]\";s:14:\"search/(.+)/?$\";s:23:\"index.php?s=$matches[1]\";s:47:\"author/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?author_name=$matches[1]&feed=$matches[2]\";s:42:\"author/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?author_name=$matches[1]&feed=$matches[2]\";s:23:\"author/([^/]+)/embed/?$\";s:44:\"index.php?author_name=$matches[1]&embed=true\";s:35:\"author/([^/]+)/page/?([0-9]{1,})/?$\";s:51:\"index.php?author_name=$matches[1]&paged=$matches[2]\";s:17:\"author/([^/]+)/?$\";s:33:\"index.php?author_name=$matches[1]\";s:69:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:80:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]\";s:64:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$\";s:80:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]\";s:45:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/embed/?$\";s:74:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&embed=true\";s:57:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/page/?([0-9]{1,})/?$\";s:81:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&paged=$matches[4]\";s:39:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/?$\";s:63:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]\";s:56:\"([0-9]{4})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:64:\"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]\";s:51:\"([0-9]{4})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$\";s:64:\"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]\";s:32:\"([0-9]{4})/([0-9]{1,2})/embed/?$\";s:58:\"index.php?year=$matches[1]&monthnum=$matches[2]&embed=true\";s:44:\"([0-9]{4})/([0-9]{1,2})/page/?([0-9]{1,})/?$\";s:65:\"index.php?year=$matches[1]&monthnum=$matches[2]&paged=$matches[3]\";s:26:\"([0-9]{4})/([0-9]{1,2})/?$\";s:47:\"index.php?year=$matches[1]&monthnum=$matches[2]\";s:43:\"([0-9]{4})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?year=$matches[1]&feed=$matches[2]\";s:38:\"([0-9]{4})/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?year=$matches[1]&feed=$matches[2]\";s:19:\"([0-9]{4})/embed/?$\";s:37:\"index.php?year=$matches[1]&embed=true\";s:31:\"([0-9]{4})/page/?([0-9]{1,})/?$\";s:44:\"index.php?year=$matches[1]&paged=$matches[2]\";s:13:\"([0-9]{4})/?$\";s:26:\"index.php?year=$matches[1]\";s:58:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:68:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:88:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:83:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:83:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:64:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:53:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/embed/?$\";s:91:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&embed=true\";s:57:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/trackback/?$\";s:85:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&tb=1\";s:77:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:97:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&feed=$matches[5]\";s:72:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:97:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&feed=$matches[5]\";s:65:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/page/?([0-9]{1,})/?$\";s:98:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&paged=$matches[5]\";s:72:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/comment-page-([0-9]{1,})/?$\";s:98:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&cpage=$matches[5]\";s:61:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)(?:/([0-9]+))?/?$\";s:97:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&page=$matches[5]\";s:47:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:57:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:77:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:72:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:72:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:53:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:64:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/comment-page-([0-9]{1,})/?$\";s:81:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&cpage=$matches[4]\";s:51:\"([0-9]{4})/([0-9]{1,2})/comment-page-([0-9]{1,})/?$\";s:65:\"index.php?year=$matches[1]&monthnum=$matches[2]&cpage=$matches[3]\";s:38:\"([0-9]{4})/comment-page-([0-9]{1,})/?$\";s:44:\"index.php?year=$matches[1]&cpage=$matches[2]\";s:27:\".?.+?/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:37:\".?.+?/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:57:\".?.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\".?.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\".?.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:33:\".?.+?/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:16:\"(.?.+?)/embed/?$\";s:41:\"index.php?pagename=$matches[1]&embed=true\";s:20:\"(.?.+?)/trackback/?$\";s:35:\"index.php?pagename=$matches[1]&tb=1\";s:40:\"(.?.+?)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:47:\"index.php?pagename=$matches[1]&feed=$matches[2]\";s:35:\"(.?.+?)/(feed|rdf|rss|rss2|atom)/?$\";s:47:\"index.php?pagename=$matches[1]&feed=$matches[2]\";s:28:\"(.?.+?)/page/?([0-9]{1,})/?$\";s:48:\"index.php?pagename=$matches[1]&paged=$matches[2]\";s:35:\"(.?.+?)/comment-page-([0-9]{1,})/?$\";s:48:\"index.php?pagename=$matches[1]&cpage=$matches[2]\";s:24:\"(.?.+?)(?:/([0-9]+))?/?$\";s:47:\"index.php?pagename=$matches[1]&page=$matches[2]\";}', 'yes'),
(30, 'hack_file', '0', 'yes'),
(31, 'blog_charset', 'UTF-8', 'yes'),
(32, 'moderation_keys', '', 'no'),
(33, 'active_plugins', 'a:2:{i:0;s:34:\"advanced-custom-fields-pro/acf.php\";i:1;s:33:\"classic-editor/classic-editor.php\";}', 'yes'),
(34, 'category_base', '', 'yes'),
(35, 'ping_sites', 'http://rpc.pingomatic.com/', 'yes'),
(36, 'comment_max_links', '2', 'yes'),
(37, 'gmt_offset', '3', 'yes'),
(38, 'default_email_category', '1', 'yes'),
(39, 'recently_edited', '', 'no'),
(40, 'template', 'tajam', 'yes'),
(41, 'stylesheet', 'tajam', 'yes'),
(42, 'comment_whitelist', '1', 'yes'),
(43, 'blacklist_keys', '', 'no'),
(44, 'comment_registration', '0', 'yes'),
(45, 'html_type', 'text/html', 'yes'),
(46, 'use_trackback', '0', 'yes'),
(47, 'default_role', 'subscriber', 'yes'),
(48, 'db_version', '44719', 'yes'),
(49, 'uploads_use_yearmonth_folders', '1', 'yes'),
(50, 'upload_path', '', 'yes'),
(51, 'blog_public', '0', 'yes'),
(52, 'default_link_category', '2', 'yes'),
(53, 'show_on_front', 'page', 'yes'),
(54, 'tag_base', '', 'yes'),
(55, 'show_avatars', '1', 'yes'),
(56, 'avatar_rating', 'G', 'yes'),
(57, 'upload_url_path', '', 'yes'),
(58, 'thumbnail_size_w', '150', 'yes'),
(59, 'thumbnail_size_h', '150', 'yes'),
(60, 'thumbnail_crop', '1', 'yes'),
(61, 'medium_size_w', '300', 'yes'),
(62, 'medium_size_h', '300', 'yes'),
(63, 'avatar_default', 'mystery', 'yes'),
(64, 'large_size_w', '1024', 'yes'),
(65, 'large_size_h', '1024', 'yes'),
(66, 'image_default_link_type', 'none', 'yes'),
(67, 'image_default_size', '', 'yes'),
(68, 'image_default_align', '', 'yes'),
(69, 'close_comments_for_old_posts', '0', 'yes'),
(70, 'close_comments_days_old', '14', 'yes'),
(71, 'thread_comments', '1', 'yes'),
(72, 'thread_comments_depth', '5', 'yes'),
(73, 'page_comments', '0', 'yes'),
(74, 'comments_per_page', '50', 'yes'),
(75, 'default_comments_page', 'newest', 'yes'),
(76, 'comment_order', 'asc', 'yes'),
(77, 'sticky_posts', 'a:0:{}', 'yes'),
(78, 'widget_categories', 'a:2:{i:2;a:4:{s:5:\"title\";s:0:\"\";s:5:\"count\";i:0;s:12:\"hierarchical\";i:0;s:8:\"dropdown\";i:0;}s:12:\"_multiwidget\";i:1;}', 'yes'),
(79, 'widget_text', 'a:2:{i:1;a:0:{}s:12:\"_multiwidget\";i:1;}', 'yes'),
(80, 'widget_rss', 'a:2:{i:1;a:0:{}s:12:\"_multiwidget\";i:1;}', 'yes'),
(81, 'uninstall_plugins', 'a:1:{s:33:\"classic-editor/classic-editor.php\";a:2:{i:0;s:14:\"Classic_Editor\";i:1;s:9:\"uninstall\";}}', 'no'),
(82, 'timezone_string', '', 'yes'),
(83, 'page_for_posts', '0', 'yes'),
(84, 'page_on_front', '6', 'yes'),
(85, 'default_post_format', '0', 'yes'),
(86, 'link_manager_enabled', '0', 'yes'),
(87, 'finished_splitting_shared_terms', '1', 'yes'),
(88, 'site_icon', '0', 'yes'),
(89, 'medium_large_size_w', '768', 'yes'),
(90, 'medium_large_size_h', '0', 'yes'),
(91, 'wp_page_for_privacy_policy', '3', 'yes'),
(92, 'show_comments_cookies_opt_in', '1', 'yes'),
(93, 'initial_db_version', '44719', 'yes'),
(94, 'wp_user_roles', 'a:5:{s:13:\"administrator\";a:2:{s:4:\"name\";s:13:\"Administrator\";s:12:\"capabilities\";a:61:{s:13:\"switch_themes\";b:1;s:11:\"edit_themes\";b:1;s:16:\"activate_plugins\";b:1;s:12:\"edit_plugins\";b:1;s:10:\"edit_users\";b:1;s:10:\"edit_files\";b:1;s:14:\"manage_options\";b:1;s:17:\"moderate_comments\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:12:\"upload_files\";b:1;s:6:\"import\";b:1;s:15:\"unfiltered_html\";b:1;s:10:\"edit_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:10:\"edit_pages\";b:1;s:4:\"read\";b:1;s:8:\"level_10\";b:1;s:7:\"level_9\";b:1;s:7:\"level_8\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:17:\"edit_others_pages\";b:1;s:20:\"edit_published_pages\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_pages\";b:1;s:19:\"delete_others_pages\";b:1;s:22:\"delete_published_pages\";b:1;s:12:\"delete_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:22:\"delete_published_posts\";b:1;s:20:\"delete_private_posts\";b:1;s:18:\"edit_private_posts\";b:1;s:18:\"read_private_posts\";b:1;s:20:\"delete_private_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"read_private_pages\";b:1;s:12:\"delete_users\";b:1;s:12:\"create_users\";b:1;s:17:\"unfiltered_upload\";b:1;s:14:\"edit_dashboard\";b:1;s:14:\"update_plugins\";b:1;s:14:\"delete_plugins\";b:1;s:15:\"install_plugins\";b:1;s:13:\"update_themes\";b:1;s:14:\"install_themes\";b:1;s:11:\"update_core\";b:1;s:10:\"list_users\";b:1;s:12:\"remove_users\";b:1;s:13:\"promote_users\";b:1;s:18:\"edit_theme_options\";b:1;s:13:\"delete_themes\";b:1;s:6:\"export\";b:1;}}s:6:\"editor\";a:2:{s:4:\"name\";s:6:\"Editor\";s:12:\"capabilities\";a:34:{s:17:\"moderate_comments\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:12:\"upload_files\";b:1;s:15:\"unfiltered_html\";b:1;s:10:\"edit_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:10:\"edit_pages\";b:1;s:4:\"read\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:17:\"edit_others_pages\";b:1;s:20:\"edit_published_pages\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_pages\";b:1;s:19:\"delete_others_pages\";b:1;s:22:\"delete_published_pages\";b:1;s:12:\"delete_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:22:\"delete_published_posts\";b:1;s:20:\"delete_private_posts\";b:1;s:18:\"edit_private_posts\";b:1;s:18:\"read_private_posts\";b:1;s:20:\"delete_private_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"read_private_pages\";b:1;}}s:6:\"author\";a:2:{s:4:\"name\";s:6:\"Author\";s:12:\"capabilities\";a:10:{s:12:\"upload_files\";b:1;s:10:\"edit_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:4:\"read\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:12:\"delete_posts\";b:1;s:22:\"delete_published_posts\";b:1;}}s:11:\"contributor\";a:2:{s:4:\"name\";s:11:\"Contributor\";s:12:\"capabilities\";a:5:{s:10:\"edit_posts\";b:1;s:4:\"read\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:12:\"delete_posts\";b:1;}}s:10:\"subscriber\";a:2:{s:4:\"name\";s:10:\"Subscriber\";s:12:\"capabilities\";a:2:{s:4:\"read\";b:1;s:7:\"level_0\";b:1;}}}', 'yes'),
(95, 'fresh_site', '0', 'yes'),
(96, 'WPLANG', '', 'yes'),
(97, 'widget_search', 'a:2:{i:2;a:1:{s:5:\"title\";s:0:\"\";}s:12:\"_multiwidget\";i:1;}', 'yes'),
(98, 'widget_recent-posts', 'a:2:{i:2;a:2:{s:5:\"title\";s:0:\"\";s:6:\"number\";i:5;}s:12:\"_multiwidget\";i:1;}', 'yes'),
(99, 'widget_recent-comments', 'a:2:{i:2;a:2:{s:5:\"title\";s:0:\"\";s:6:\"number\";i:5;}s:12:\"_multiwidget\";i:1;}', 'yes'),
(100, 'widget_archives', 'a:2:{i:2;a:3:{s:5:\"title\";s:0:\"\";s:5:\"count\";i:0;s:8:\"dropdown\";i:0;}s:12:\"_multiwidget\";i:1;}', 'yes'),
(101, 'widget_meta', 'a:2:{i:2;a:1:{s:5:\"title\";s:0:\"\";}s:12:\"_multiwidget\";i:1;}', 'yes'),
(102, 'sidebars_widgets', 'a:2:{s:19:\"wp_inactive_widgets\";a:6:{i:0;s:8:\"search-2\";i:1;s:14:\"recent-posts-2\";i:2;s:17:\"recent-comments-2\";i:3;s:10:\"archives-2\";i:4;s:12:\"categories-2\";i:5;s:6:\"meta-2\";}s:13:\"array_version\";i:3;}', 'yes'),
(103, 'widget_pages', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(104, 'widget_calendar', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(105, 'widget_media_audio', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(106, 'widget_media_image', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(107, 'widget_media_gallery', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(108, 'widget_media_video', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(109, 'widget_tag_cloud', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(110, 'widget_nav_menu', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(111, 'widget_custom_html', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(112, 'cron', 'a:5:{i:1554982970;a:1:{s:34:\"wp_privacy_delete_old_export_files\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:6:\"hourly\";s:4:\"args\";a:0:{}s:8:\"interval\";i:3600;}}}i:1555015370;a:3:{s:16:\"wp_version_check\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}s:17:\"wp_update_plugins\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}s:16:\"wp_update_themes\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}}i:1555058593;a:2:{s:19:\"wp_scheduled_delete\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}s:25:\"delete_expired_transients\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1555058676;a:1:{s:30:\"wp_scheduled_auto_draft_delete\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}s:7:\"version\";i:2;}', 'yes'),
(113, 'theme_mods_twentynineteen', 'a:2:{s:18:\"custom_css_post_id\";i:-1;s:16:\"sidebars_widgets\";a:2:{s:4:\"time\";i:1554799920;s:4:\"data\";a:2:{s:19:\"wp_inactive_widgets\";a:0:{}s:9:\"sidebar-1\";a:6:{i:0;s:8:\"search-2\";i:1;s:14:\"recent-posts-2\";i:2;s:17:\"recent-comments-2\";i:3;s:10:\"archives-2\";i:4;s:12:\"categories-2\";i:5;s:6:\"meta-2\";}}}}', 'yes'),
(121, '_site_transient_timeout_browser_f40eb9183e22442d742d2ae85c0aa60b', '1555404180', 'no'),
(122, '_site_transient_browser_f40eb9183e22442d742d2ae85c0aa60b', 'a:10:{s:4:\"name\";s:6:\"Chrome\";s:7:\"version\";s:12:\"73.0.3683.86\";s:8:\"platform\";s:9:\"Macintosh\";s:10:\"update_url\";s:29:\"https://www.google.com/chrome\";s:7:\"img_src\";s:43:\"http://s.w.org/images/browsers/chrome.png?1\";s:11:\"img_src_ssl\";s:44:\"https://s.w.org/images/browsers/chrome.png?1\";s:15:\"current_version\";s:2:\"18\";s:7:\"upgrade\";b:0;s:8:\"insecure\";b:0;s:6:\"mobile\";b:0;}', 'no'),
(123, '_site_transient_timeout_php_check_80cadeb689bccc0409faf12154bcfbb7', '1555404180', 'no'),
(124, '_site_transient_php_check_80cadeb689bccc0409faf12154bcfbb7', 'a:5:{s:19:\"recommended_version\";s:3:\"7.3\";s:15:\"minimum_version\";s:5:\"5.2.4\";s:12:\"is_supported\";b:0;s:9:\"is_secure\";b:1;s:13:\"is_acceptable\";b:1;}', 'no'),
(125, 'can_compress_scripts', '1', 'no'),
(144, 'recently_activated', 'a:1:{s:30:\"advanced-custom-fields/acf.php\";i:1554807917;}', 'yes'),
(153, 'theme_mods_tajam', 'a:13:{s:18:\"custom_css_post_id\";i:-1;s:18:\"nav_menu_locations\";a:2:{s:6:\"header\";i:2;s:6:\"footer\";i:3;}s:10:\"logo_image\";s:63:\"http://localhost:8888/tajam/wp-content/uploads/2019/04/logo.png\";s:17:\"logo_image_footer\";s:63:\"http://localhost:8888/tajam/wp-content/uploads/2019/04/logo.png\";s:22:\"footer_social_facebook\";s:1:\"#\";s:21:\"footer_social_twitter\";s:1:\"#\";s:22:\"footer_social_dribbble\";s:1:\"#\";s:23:\"footer_social_instagram\";s:1:\"#\";s:20:\"footer_social_google\";s:1:\"#\";s:21:\"footer_social_youtube\";s:1:\"#\";s:10:\"footer_tel\";s:18:\"(+62) 21-2224 3333\";s:15:\"footer_location\";s:93:\"Ruko cucruk, Jl. Radio luar dalem jos No.12 - 13, Kalideres - Jakarta Barat 11480 - Indonesia\";s:11:\"footer_text\";s:157:\"lorem quis bibendum auctor, nisi elit consequat ipsum, nec sagittis sem nibh elit. Duis sed odio sit amet auctror a ornare odio non mauris vitae erat in elit\";}', 'yes'),
(154, 'current_theme', 'Tajam', 'yes'),
(155, 'theme_switched', '', 'yes'),
(157, 'nav_menu_options', 'a:1:{s:8:\"auto_add\";a:0:{}}', 'yes'),
(159, 'acf_version', '5.7.7', 'yes'),
(162, 'new_admin_email', 'farik4098@gmail.com', 'yes'),
(183, '_site_transient_timeout_browser_5045c32db05d7534e41af64e658b3ab1', '1555489336', 'no'),
(184, '_site_transient_browser_5045c32db05d7534e41af64e658b3ab1', 'a:10:{s:4:\"name\";s:6:\"Safari\";s:7:\"version\";s:6:\"12.0.3\";s:8:\"platform\";s:9:\"Macintosh\";s:10:\"update_url\";s:29:\"https://www.apple.com/safari/\";s:7:\"img_src\";s:43:\"http://s.w.org/images/browsers/safari.png?1\";s:11:\"img_src_ssl\";s:44:\"https://s.w.org/images/browsers/safari.png?1\";s:15:\"current_version\";s:2:\"11\";s:7:\"upgrade\";b:0;s:8:\"insecure\";b:0;s:6:\"mobile\";b:0;}', 'no'),
(204, '_transient_timeout_acf_plugin_updates', '1555058619', 'no'),
(205, '_transient_acf_plugin_updates', 'a:4:{s:7:\"plugins\";a:1:{s:34:\"advanced-custom-fields-pro/acf.php\";a:8:{s:4:\"slug\";s:26:\"advanced-custom-fields-pro\";s:6:\"plugin\";s:34:\"advanced-custom-fields-pro/acf.php\";s:11:\"new_version\";s:6:\"5.7.13\";s:3:\"url\";s:37:\"https://www.advancedcustomfields.com/\";s:6:\"tested\";s:5:\"4.9.9\";s:7:\"package\";s:0:\"\";s:5:\"icons\";a:1:{s:7:\"default\";s:63:\"https://ps.w.org/advanced-custom-fields/assets/icon-256x256.png\";}s:7:\"banners\";a:1:{s:7:\"default\";s:66:\"https://ps.w.org/advanced-custom-fields/assets/banner-1544x500.jpg\";}}}s:10:\"expiration\";i:86400;s:6:\"status\";i:1;s:7:\"checked\";a:1:{s:34:\"advanced-custom-fields-pro/acf.php\";s:5:\"5.7.7\";}}', 'no'),
(206, '_site_transient_timeout_theme_roots', '1554974020', 'no'),
(207, '_site_transient_theme_roots', 'a:1:{s:5:\"tajam\";s:7:\"/themes\";}', 'no'),
(209, '_site_transient_update_core', 'O:8:\"stdClass\":4:{s:7:\"updates\";a:1:{i:0;O:8:\"stdClass\":10:{s:8:\"response\";s:6:\"latest\";s:8:\"download\";s:59:\"https://downloads.wordpress.org/release/wordpress-5.1.1.zip\";s:6:\"locale\";s:5:\"en_US\";s:8:\"packages\";O:8:\"stdClass\":5:{s:4:\"full\";s:59:\"https://downloads.wordpress.org/release/wordpress-5.1.1.zip\";s:10:\"no_content\";s:70:\"https://downloads.wordpress.org/release/wordpress-5.1.1-no-content.zip\";s:11:\"new_bundled\";s:71:\"https://downloads.wordpress.org/release/wordpress-5.1.1-new-bundled.zip\";s:7:\"partial\";b:0;s:8:\"rollback\";b:0;}s:7:\"current\";s:5:\"5.1.1\";s:7:\"version\";s:5:\"5.1.1\";s:11:\"php_version\";s:5:\"5.2.4\";s:13:\"mysql_version\";s:3:\"5.0\";s:11:\"new_bundled\";s:3:\"5.0\";s:15:\"partial_version\";s:0:\"\";}}s:12:\"last_checked\";i:1554972223;s:15:\"version_checked\";s:5:\"5.1.1\";s:12:\"translations\";a:0:{}}', 'no'),
(210, '_site_transient_update_themes', 'O:8:\"stdClass\":4:{s:12:\"last_checked\";i:1554972224;s:7:\"checked\";a:1:{s:5:\"tajam\";s:3:\"1.0\";}s:8:\"response\";a:0:{}s:12:\"translations\";a:0:{}}', 'no'),
(211, '_site_transient_update_plugins', 'O:8:\"stdClass\":5:{s:12:\"last_checked\";i:1554972225;s:7:\"checked\";a:3:{s:34:\"advanced-custom-fields-pro/acf.php\";s:5:\"5.7.7\";s:19:\"akismet/akismet.php\";s:5:\"4.1.1\";s:33:\"classic-editor/classic-editor.php\";s:3:\"1.4\";}s:8:\"response\";a:1:{s:34:\"advanced-custom-fields-pro/acf.php\";O:8:\"stdClass\":8:{s:4:\"slug\";s:26:\"advanced-custom-fields-pro\";s:6:\"plugin\";s:34:\"advanced-custom-fields-pro/acf.php\";s:11:\"new_version\";s:6:\"5.7.13\";s:3:\"url\";s:37:\"https://www.advancedcustomfields.com/\";s:6:\"tested\";s:5:\"4.9.9\";s:7:\"package\";s:0:\"\";s:5:\"icons\";a:1:{s:7:\"default\";s:63:\"https://ps.w.org/advanced-custom-fields/assets/icon-256x256.png\";}s:7:\"banners\";a:1:{s:7:\"default\";s:66:\"https://ps.w.org/advanced-custom-fields/assets/banner-1544x500.jpg\";}}}s:12:\"translations\";a:1:{i:0;a:7:{s:4:\"type\";s:6:\"plugin\";s:4:\"slug\";s:14:\"classic-editor\";s:8:\"language\";s:5:\"ru_RU\";s:7:\"version\";s:3:\"1.4\";s:7:\"updated\";s:19:\"2019-02-20 19:00:57\";s:7:\"package\";s:79:\"https://downloads.wordpress.org/translation/plugin/classic-editor/1.4/ru_RU.zip\";s:10:\"autoupdate\";b:1;}}s:9:\"no_update\";a:2:{s:19:\"akismet/akismet.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:21:\"w.org/plugins/akismet\";s:4:\"slug\";s:7:\"akismet\";s:6:\"plugin\";s:19:\"akismet/akismet.php\";s:11:\"new_version\";s:5:\"4.1.1\";s:3:\"url\";s:38:\"https://wordpress.org/plugins/akismet/\";s:7:\"package\";s:56:\"https://downloads.wordpress.org/plugin/akismet.4.1.1.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:59:\"https://ps.w.org/akismet/assets/icon-256x256.png?rev=969272\";s:2:\"1x\";s:59:\"https://ps.w.org/akismet/assets/icon-128x128.png?rev=969272\";}s:7:\"banners\";a:1:{s:2:\"1x\";s:61:\"https://ps.w.org/akismet/assets/banner-772x250.jpg?rev=479904\";}s:11:\"banners_rtl\";a:0:{}}s:33:\"classic-editor/classic-editor.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:28:\"w.org/plugins/classic-editor\";s:4:\"slug\";s:14:\"classic-editor\";s:6:\"plugin\";s:33:\"classic-editor/classic-editor.php\";s:11:\"new_version\";s:3:\"1.4\";s:3:\"url\";s:45:\"https://wordpress.org/plugins/classic-editor/\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/plugin/classic-editor.1.4.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:67:\"https://ps.w.org/classic-editor/assets/icon-256x256.png?rev=1998671\";s:2:\"1x\";s:67:\"https://ps.w.org/classic-editor/assets/icon-128x128.png?rev=1998671\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:70:\"https://ps.w.org/classic-editor/assets/banner-1544x500.png?rev=1998671\";s:2:\"1x\";s:69:\"https://ps.w.org/classic-editor/assets/banner-772x250.png?rev=1998676\";}s:11:\"banners_rtl\";a:0:{}}}}', 'no');

-- --------------------------------------------------------

--
-- Table structure for table `wp_postmeta`
--

CREATE TABLE `wp_postmeta` (
  `meta_id` bigint(20) UNSIGNED NOT NULL,
  `post_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Dumping data for table `wp_postmeta`
--

INSERT INTO `wp_postmeta` (`meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(1, 2, '_wp_page_template', 'default'),
(2, 3, '_wp_page_template', 'default'),
(3, 5, '_edit_lock', '1554799342:1'),
(4, 6, '_edit_last', '1'),
(5, 6, '_edit_lock', '1554903360:1'),
(6, 6, '_wp_page_template', 'templates/home.php'),
(7, 8, '_wp_attached_file', '2019/04/logo.png'),
(8, 8, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:128;s:6:\"height\";i:50;s:4:\"file\";s:16:\"2019/04/logo.png\";s:5:\"sizes\";a:0:{}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(9, 9, '_edit_lock', '1554804487:1'),
(10, 9, '_customize_restore_dismissed', '1'),
(11, 10, '_wp_trash_meta_status', 'publish'),
(12, 10, '_wp_trash_meta_time', '1554804510'),
(13, 11, '_edit_lock', '1554805758:1'),
(14, 12, '_menu_item_type', 'custom'),
(15, 12, '_menu_item_menu_item_parent', '0'),
(16, 12, '_menu_item_object_id', '12'),
(17, 12, '_menu_item_object', 'custom'),
(18, 12, '_menu_item_target', ''),
(19, 12, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(20, 12, '_menu_item_xfn', ''),
(21, 12, '_menu_item_url', '#'),
(22, 13, '_menu_item_type', 'custom'),
(23, 13, '_menu_item_menu_item_parent', '0'),
(24, 13, '_menu_item_object_id', '13'),
(25, 13, '_menu_item_object', 'custom'),
(26, 13, '_menu_item_target', ''),
(27, 13, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(28, 13, '_menu_item_xfn', ''),
(29, 13, '_menu_item_url', '#'),
(30, 14, '_menu_item_type', 'custom'),
(31, 14, '_menu_item_menu_item_parent', '0'),
(32, 14, '_menu_item_object_id', '14'),
(33, 14, '_menu_item_object', 'custom'),
(34, 14, '_menu_item_target', ''),
(35, 14, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(36, 14, '_menu_item_xfn', ''),
(37, 14, '_menu_item_url', '#'),
(38, 15, '_menu_item_type', 'custom'),
(39, 15, '_menu_item_menu_item_parent', '0'),
(40, 15, '_menu_item_object_id', '15'),
(41, 15, '_menu_item_object', 'custom'),
(42, 15, '_menu_item_target', ''),
(43, 15, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(44, 15, '_menu_item_xfn', ''),
(45, 15, '_menu_item_url', '#'),
(46, 16, '_menu_item_type', 'custom'),
(47, 16, '_menu_item_menu_item_parent', '0'),
(48, 16, '_menu_item_object_id', '16'),
(49, 16, '_menu_item_object', 'custom'),
(50, 16, '_menu_item_target', ''),
(51, 16, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(52, 16, '_menu_item_xfn', ''),
(53, 16, '_menu_item_url', '#'),
(54, 17, '_menu_item_type', 'custom'),
(55, 17, '_menu_item_menu_item_parent', '0'),
(56, 17, '_menu_item_object_id', '17'),
(57, 17, '_menu_item_object', 'custom'),
(58, 17, '_menu_item_target', ''),
(59, 17, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(60, 17, '_menu_item_xfn', ''),
(61, 17, '_menu_item_url', '#'),
(62, 18, '_menu_item_type', 'post_type'),
(63, 18, '_menu_item_menu_item_parent', '0'),
(64, 18, '_menu_item_object_id', '6'),
(65, 18, '_menu_item_object', 'page'),
(66, 18, '_menu_item_target', ''),
(67, 18, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(68, 18, '_menu_item_xfn', ''),
(69, 18, '_menu_item_url', ''),
(70, 11, '_wp_trash_meta_status', 'publish'),
(71, 11, '_wp_trash_meta_time', '1554805759'),
(72, 20, '_edit_last', '1'),
(73, 20, '_edit_lock', '1554895287:1'),
(74, 27, '_wp_attached_file', '2019/04/banner_image.png'),
(75, 27, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:1600;s:6:\"height\";i:670;s:4:\"file\";s:24:\"2019/04/banner_image.png\";s:5:\"sizes\";a:4:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:24:\"banner_image-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:6:\"medium\";a:4:{s:4:\"file\";s:24:\"banner_image-300x126.png\";s:5:\"width\";i:300;s:6:\"height\";i:126;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:24:\"banner_image-768x322.png\";s:5:\"width\";i:768;s:6:\"height\";i:322;s:9:\"mime-type\";s:9:\"image/png\";}s:5:\"large\";a:4:{s:4:\"file\";s:25:\"banner_image-1024x429.png\";s:5:\"width\";i:1024;s:6:\"height\";i:429;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(76, 6, 'home_banner_home_banner_image', '27'),
(77, 6, '_home_banner_home_banner_image', 'field_5cac7ce9a8c53'),
(78, 6, 'home_banner_home_banner_slides_0_slide_title', 'We Are Awesome Creative Agency'),
(79, 6, '_home_banner_home_banner_slides_0_slide_title', 'field_5cac7d27a8c55'),
(80, 6, 'home_banner_home_banner_slides_0_slide_text', 'This is Photoshop\'s version  of Lorem Ipsum. Proin gravida nibh vel velit auctor aliquet. Aenean sollicitudin, lorem quis bibendum auctor, nisi elit consequat ipsum, nec sagittis sem nibh id elit. Duis sed odio sit amet nibh vulputate cursus a sit amet mauris. Morbi accumsan ipsum velit.'),
(81, 6, '_home_banner_home_banner_slides_0_slide_text', 'field_5cac7d3da8c56'),
(82, 6, 'home_banner_home_banner_slides_0_slide_link', 'a:3:{s:5:\"title\";s:10:\"Learn more\";s:3:\"url\";s:1:\"#\";s:6:\"target\";s:0:\"\";}'),
(83, 6, '_home_banner_home_banner_slides_0_slide_link', 'field_5cac7d4ca8c57'),
(84, 6, 'home_banner_home_banner_slides', '4'),
(85, 6, '_home_banner_home_banner_slides', 'field_5cac7d05a8c54'),
(86, 6, 'home_banner', ''),
(87, 6, '_home_banner', 'field_5cac7caea8c52'),
(88, 28, 'home_banner_home_banner_image', '27'),
(89, 28, '_home_banner_home_banner_image', 'field_5cac7ce9a8c53'),
(90, 28, 'home_banner_home_banner_slides_0_slide_title', 'We Are Awesome Creative Agency'),
(91, 28, '_home_banner_home_banner_slides_0_slide_title', 'field_5cac7d27a8c55'),
(92, 28, 'home_banner_home_banner_slides_0_slide_text', 'This is Photoshop\'s version  of Lorem Ipsum. Proin gravida nibh vel velit auctor aliquet. Aenean sollicitudin, lorem quis bibendum auctor, nisi elit consequat ipsum, nec sagittis sem nibh id elit. Duis sed odio sit amet nibh vulputate cursus a sit amet mauris. Morbi accumsan ipsum velit.'),
(93, 28, '_home_banner_home_banner_slides_0_slide_text', 'field_5cac7d3da8c56'),
(94, 28, 'home_banner_home_banner_slides_0_slide_link', 'a:3:{s:5:\"title\";s:10:\"Learn more\";s:3:\"url\";s:1:\"#\";s:6:\"target\";s:0:\"\";}'),
(95, 28, '_home_banner_home_banner_slides_0_slide_link', 'field_5cac7d4ca8c57'),
(96, 28, 'home_banner_home_banner_slides', '1'),
(97, 28, '_home_banner_home_banner_slides', 'field_5cac7d05a8c54'),
(98, 28, 'home_banner', ''),
(99, 28, '_home_banner', 'field_5cac7caea8c52'),
(100, 6, 'home_banner_home_banner_slides_1_slide_title', 'We Are Awesome Creative Agency 2'),
(101, 6, '_home_banner_home_banner_slides_1_slide_title', 'field_5cac7d27a8c55'),
(102, 6, 'home_banner_home_banner_slides_1_slide_text', 'This is Photoshop\'s version  of Lorem Ipsum. Proin gravida nibh vel velit auctor aliquet. Aenean sollicitudin, lorem quis bibendum auctor, nisi elit consequat ipsum, nec sagittis sem nibh id elit. Duis sed odio sit amet nibh vulputate cursus a sit amet mauris. Morbi accumsan ipsum velit.'),
(103, 6, '_home_banner_home_banner_slides_1_slide_text', 'field_5cac7d3da8c56'),
(104, 6, 'home_banner_home_banner_slides_1_slide_link', 'a:3:{s:5:\"title\";s:6:\"Get it\";s:3:\"url\";s:1:\"#\";s:6:\"target\";s:0:\"\";}'),
(105, 6, '_home_banner_home_banner_slides_1_slide_link', 'field_5cac7d4ca8c57'),
(106, 6, 'home_banner_home_banner_slides_2_slide_title', 'We Are Awesome Creative Agency 3'),
(107, 6, '_home_banner_home_banner_slides_2_slide_title', 'field_5cac7d27a8c55'),
(108, 6, 'home_banner_home_banner_slides_2_slide_text', 'This is Photoshop\'s version  of Lorem Ipsum. Proin gravida nibh vel velit auctor aliquet. Aenean sollicitudin, lorem quis bibendum auctor, nisi elit consequat ipsum, nec sagittis sem nibh id elit. Duis sed odio sit amet nibh vulputate cursus a sit amet mauris. Morbi accumsan ipsum velit.'),
(109, 6, '_home_banner_home_banner_slides_2_slide_text', 'field_5cac7d3da8c56'),
(110, 6, 'home_banner_home_banner_slides_2_slide_link', 'a:3:{s:5:\"title\";s:10:\"Learn more\";s:3:\"url\";s:1:\"#\";s:6:\"target\";s:0:\"\";}'),
(111, 6, '_home_banner_home_banner_slides_2_slide_link', 'field_5cac7d4ca8c57'),
(112, 6, 'home_banner_home_banner_slides_3_slide_title', 'We Are Awesome Creative Agency 4'),
(113, 6, '_home_banner_home_banner_slides_3_slide_title', 'field_5cac7d27a8c55'),
(114, 6, 'home_banner_home_banner_slides_3_slide_text', 'This is Photoshop\'s version  of Lorem Ipsum. Proin gravida nibh vel velit auctor aliquet. Aenean sollicitudin, lorem quis bibendum auctor, nisi elit consequat ipsum, nec sagittis sem nibh id elit. Duis sed odio sit amet nibh vulputate cursus a sit amet mauris. Morbi accumsan ipsum velit.'),
(115, 6, '_home_banner_home_banner_slides_3_slide_text', 'field_5cac7d3da8c56'),
(116, 6, 'home_banner_home_banner_slides_3_slide_link', 'a:3:{s:5:\"title\";s:10:\"Learn more\";s:3:\"url\";s:1:\"#\";s:6:\"target\";s:0:\"\";}'),
(117, 6, '_home_banner_home_banner_slides_3_slide_link', 'field_5cac7d4ca8c57'),
(118, 29, 'home_banner_home_banner_image', '27'),
(119, 29, '_home_banner_home_banner_image', 'field_5cac7ce9a8c53'),
(120, 29, 'home_banner_home_banner_slides_0_slide_title', 'We Are Awesome Creative Agency'),
(121, 29, '_home_banner_home_banner_slides_0_slide_title', 'field_5cac7d27a8c55'),
(122, 29, 'home_banner_home_banner_slides_0_slide_text', 'This is Photoshop\'s version  of Lorem Ipsum. Proin gravida nibh vel velit auctor aliquet. Aenean sollicitudin, lorem quis bibendum auctor, nisi elit consequat ipsum, nec sagittis sem nibh id elit. Duis sed odio sit amet nibh vulputate cursus a sit amet mauris. Morbi accumsan ipsum velit.'),
(123, 29, '_home_banner_home_banner_slides_0_slide_text', 'field_5cac7d3da8c56'),
(124, 29, 'home_banner_home_banner_slides_0_slide_link', 'a:3:{s:5:\"title\";s:10:\"Learn more\";s:3:\"url\";s:1:\"#\";s:6:\"target\";s:0:\"\";}'),
(125, 29, '_home_banner_home_banner_slides_0_slide_link', 'field_5cac7d4ca8c57'),
(126, 29, 'home_banner_home_banner_slides', '4'),
(127, 29, '_home_banner_home_banner_slides', 'field_5cac7d05a8c54'),
(128, 29, 'home_banner', ''),
(129, 29, '_home_banner', 'field_5cac7caea8c52'),
(130, 29, 'home_banner_home_banner_slides_1_slide_title', 'We Are Awesome Creative Agency 2'),
(131, 29, '_home_banner_home_banner_slides_1_slide_title', 'field_5cac7d27a8c55'),
(132, 29, 'home_banner_home_banner_slides_1_slide_text', 'This is Photoshop\'s version  of Lorem Ipsum. Proin gravida nibh vel velit auctor aliquet. Aenean sollicitudin, lorem quis bibendum auctor, nisi elit consequat ipsum, nec sagittis sem nibh id elit. Duis sed odio sit amet nibh vulputate cursus a sit amet mauris. Morbi accumsan ipsum velit.'),
(133, 29, '_home_banner_home_banner_slides_1_slide_text', 'field_5cac7d3da8c56'),
(134, 29, 'home_banner_home_banner_slides_1_slide_link', 'a:3:{s:5:\"title\";s:6:\"Get it\";s:3:\"url\";s:1:\"#\";s:6:\"target\";s:0:\"\";}'),
(135, 29, '_home_banner_home_banner_slides_1_slide_link', 'field_5cac7d4ca8c57'),
(136, 29, 'home_banner_home_banner_slides_2_slide_title', 'We Are Awesome Creative Agency 3'),
(137, 29, '_home_banner_home_banner_slides_2_slide_title', 'field_5cac7d27a8c55'),
(138, 29, 'home_banner_home_banner_slides_2_slide_text', 'This is Photoshop\'s version  of Lorem Ipsum. Proin gravida nibh vel velit auctor aliquet. Aenean sollicitudin, lorem quis bibendum auctor, nisi elit consequat ipsum, nec sagittis sem nibh id elit. Duis sed odio sit amet nibh vulputate cursus a sit amet mauris. Morbi accumsan ipsum velit.'),
(139, 29, '_home_banner_home_banner_slides_2_slide_text', 'field_5cac7d3da8c56'),
(140, 29, 'home_banner_home_banner_slides_2_slide_link', 'a:3:{s:5:\"title\";s:10:\"Learn more\";s:3:\"url\";s:1:\"#\";s:6:\"target\";s:0:\"\";}'),
(141, 29, '_home_banner_home_banner_slides_2_slide_link', 'field_5cac7d4ca8c57'),
(142, 29, 'home_banner_home_banner_slides_3_slide_title', 'We Are Awesome Creative Agency 4'),
(143, 29, '_home_banner_home_banner_slides_3_slide_title', 'field_5cac7d27a8c55'),
(144, 29, 'home_banner_home_banner_slides_3_slide_text', 'This is Photoshop\'s version  of Lorem Ipsum. Proin gravida nibh vel velit auctor aliquet. Aenean sollicitudin, lorem quis bibendum auctor, nisi elit consequat ipsum, nec sagittis sem nibh id elit. Duis sed odio sit amet nibh vulputate cursus a sit amet mauris. Morbi accumsan ipsum velit.'),
(145, 29, '_home_banner_home_banner_slides_3_slide_text', 'field_5cac7d3da8c56'),
(146, 29, 'home_banner_home_banner_slides_3_slide_link', 'a:3:{s:5:\"title\";s:10:\"Learn more\";s:3:\"url\";s:1:\"#\";s:6:\"target\";s:0:\"\";}'),
(147, 29, '_home_banner_home_banner_slides_3_slide_link', 'field_5cac7d4ca8c57'),
(148, 44, '_wp_attached_file', '2019/04/imgg.png'),
(149, 44, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:235;s:6:\"height\";i:229;s:4:\"file\";s:16:\"2019/04/imgg.png\";s:5:\"sizes\";a:1:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:16:\"imgg-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(150, 45, '_wp_attached_file', '2019/04/ic1.png'),
(151, 45, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:49;s:6:\"height\";i:50;s:4:\"file\";s:15:\"2019/04/ic1.png\";s:5:\"sizes\";a:0:{}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(152, 6, 'story_story_image', '44'),
(153, 6, '_story_story_image', 'field_5cacdf3f00de1'),
(154, 6, 'story_story_text', 'This is Photoshop\'s version of Lorem Ipsum. Proin gravida nibh vel velit auctor aliquet. Aenean sollicitudin, lorem quis bibendum auctor, nisi elit consequat ipsum, nec sagittis sem nibh id elit. Duis sed odio sit amet nibh vulputate cursus\r\n\r\nMorbi accumsan ipsum velit. Nam nec tellus a odio tincidunt auctor a ornare odio. Sed non mauris vitae erat consequat auctor eu in elit. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos.'),
(155, 6, '_story_story_text', 'field_5cacdf6b00de2'),
(156, 6, 'story_link', 'a:3:{s:5:\"title\";s:0:\"\";s:3:\"url\";s:1:\"#\";s:6:\"target\";s:0:\"\";}'),
(157, 6, '_story_link', 'field_5cacef0cfd4d9'),
(158, 6, 'story', ''),
(159, 6, '_story', 'field_5cacdf3200de0'),
(160, 6, 'video_video_text', 'WATCH OUR STORY'),
(161, 6, '_video_video_text', 'field_5cacef454182e'),
(162, 6, 'video_video_id', '5lWkZ-JaEOc'),
(163, 6, '_video_video_id', 'field_5cacef704182f'),
(164, 6, 'video', ''),
(165, 6, '_video', 'field_5cacef294182d'),
(166, 6, 'exp_exp_title', 'EXPERTISE'),
(167, 6, '_exp_exp_title', 'field_5cacf097b44ed'),
(168, 6, 'exp_exp_subtitle', 'Lorem ipsum dolor sit amet proin gravida nibh vel velit'),
(169, 6, '_exp_exp_subtitle', 'field_5cacf0ceb44ee'),
(170, 6, 'exp_exp_items_0_e_icon', '45'),
(171, 6, '_exp_exp_items_0_e_icon', 'field_5cacf0ffb44f0'),
(172, 6, 'exp_exp_items_0_e_title', 'WEB DESIGN & DEVELOPMENT'),
(173, 6, '_exp_exp_items_0_e_title', 'field_5cacf11eb44f1'),
(174, 6, 'exp_exp_items_0_e_text', 'This is Photoshop\'s version  of Lorem Ipsum. Proin gravida nibh vel velit auctor aliquet Aenean.'),
(175, 6, '_exp_exp_items_0_e_text', 'field_5cacf12cb44f2'),
(176, 6, 'exp_exp_items', '6'),
(177, 6, '_exp_exp_items', 'field_5cacf0deb44ef'),
(178, 6, 'exp', ''),
(179, 6, '_exp', 'field_5cacf082b44ec'),
(180, 46, 'home_banner_home_banner_image', '27'),
(181, 46, '_home_banner_home_banner_image', 'field_5cac7ce9a8c53'),
(182, 46, 'home_banner_home_banner_slides_0_slide_title', 'We Are Awesome Creative Agency'),
(183, 46, '_home_banner_home_banner_slides_0_slide_title', 'field_5cac7d27a8c55'),
(184, 46, 'home_banner_home_banner_slides_0_slide_text', 'This is Photoshop\'s version  of Lorem Ipsum. Proin gravida nibh vel velit auctor aliquet. Aenean sollicitudin, lorem quis bibendum auctor, nisi elit consequat ipsum, nec sagittis sem nibh id elit. Duis sed odio sit amet nibh vulputate cursus a sit amet mauris. Morbi accumsan ipsum velit.'),
(185, 46, '_home_banner_home_banner_slides_0_slide_text', 'field_5cac7d3da8c56'),
(186, 46, 'home_banner_home_banner_slides_0_slide_link', 'a:3:{s:5:\"title\";s:10:\"Learn more\";s:3:\"url\";s:1:\"#\";s:6:\"target\";s:0:\"\";}'),
(187, 46, '_home_banner_home_banner_slides_0_slide_link', 'field_5cac7d4ca8c57'),
(188, 46, 'home_banner_home_banner_slides', '4'),
(189, 46, '_home_banner_home_banner_slides', 'field_5cac7d05a8c54'),
(190, 46, 'home_banner', ''),
(191, 46, '_home_banner', 'field_5cac7caea8c52'),
(192, 46, 'home_banner_home_banner_slides_1_slide_title', 'We Are Awesome Creative Agency 2'),
(193, 46, '_home_banner_home_banner_slides_1_slide_title', 'field_5cac7d27a8c55'),
(194, 46, 'home_banner_home_banner_slides_1_slide_text', 'This is Photoshop\'s version  of Lorem Ipsum. Proin gravida nibh vel velit auctor aliquet. Aenean sollicitudin, lorem quis bibendum auctor, nisi elit consequat ipsum, nec sagittis sem nibh id elit. Duis sed odio sit amet nibh vulputate cursus a sit amet mauris. Morbi accumsan ipsum velit.'),
(195, 46, '_home_banner_home_banner_slides_1_slide_text', 'field_5cac7d3da8c56'),
(196, 46, 'home_banner_home_banner_slides_1_slide_link', 'a:3:{s:5:\"title\";s:6:\"Get it\";s:3:\"url\";s:1:\"#\";s:6:\"target\";s:0:\"\";}'),
(197, 46, '_home_banner_home_banner_slides_1_slide_link', 'field_5cac7d4ca8c57'),
(198, 46, 'home_banner_home_banner_slides_2_slide_title', 'We Are Awesome Creative Agency 3'),
(199, 46, '_home_banner_home_banner_slides_2_slide_title', 'field_5cac7d27a8c55'),
(200, 46, 'home_banner_home_banner_slides_2_slide_text', 'This is Photoshop\'s version  of Lorem Ipsum. Proin gravida nibh vel velit auctor aliquet. Aenean sollicitudin, lorem quis bibendum auctor, nisi elit consequat ipsum, nec sagittis sem nibh id elit. Duis sed odio sit amet nibh vulputate cursus a sit amet mauris. Morbi accumsan ipsum velit.'),
(201, 46, '_home_banner_home_banner_slides_2_slide_text', 'field_5cac7d3da8c56'),
(202, 46, 'home_banner_home_banner_slides_2_slide_link', 'a:3:{s:5:\"title\";s:10:\"Learn more\";s:3:\"url\";s:1:\"#\";s:6:\"target\";s:0:\"\";}'),
(203, 46, '_home_banner_home_banner_slides_2_slide_link', 'field_5cac7d4ca8c57'),
(204, 46, 'home_banner_home_banner_slides_3_slide_title', 'We Are Awesome Creative Agency 4'),
(205, 46, '_home_banner_home_banner_slides_3_slide_title', 'field_5cac7d27a8c55'),
(206, 46, 'home_banner_home_banner_slides_3_slide_text', 'This is Photoshop\'s version  of Lorem Ipsum. Proin gravida nibh vel velit auctor aliquet. Aenean sollicitudin, lorem quis bibendum auctor, nisi elit consequat ipsum, nec sagittis sem nibh id elit. Duis sed odio sit amet nibh vulputate cursus a sit amet mauris. Morbi accumsan ipsum velit.'),
(207, 46, '_home_banner_home_banner_slides_3_slide_text', 'field_5cac7d3da8c56'),
(208, 46, 'home_banner_home_banner_slides_3_slide_link', 'a:3:{s:5:\"title\";s:10:\"Learn more\";s:3:\"url\";s:1:\"#\";s:6:\"target\";s:0:\"\";}'),
(209, 46, '_home_banner_home_banner_slides_3_slide_link', 'field_5cac7d4ca8c57'),
(210, 46, 'story_story_image', '44'),
(211, 46, '_story_story_image', 'field_5cacdf3f00de1'),
(212, 46, 'story_story_text', 'This is Photoshop\'s version of Lorem Ipsum. Proin gravida nibh vel velit auctor aliquet. Aenean sollicitudin, lorem quis bibendum auctor, nisi elit consequat ipsum, nec sagittis sem nibh id elit. Duis sed odio sit amet nibh vulputate cursus\r\n\r\nMorbi accumsan ipsum velit. Nam nec tellus a odio tincidunt auctor a ornare odio. Sed non mauris vitae erat consequat auctor eu in elit. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos.'),
(213, 46, '_story_story_text', 'field_5cacdf6b00de2'),
(214, 46, 'story_link', ''),
(215, 46, '_story_link', 'field_5cacef0cfd4d9'),
(216, 46, 'story', ''),
(217, 46, '_story', 'field_5cacdf3200de0'),
(218, 46, 'video_video_text', 'WATCH OUR STORY'),
(219, 46, '_video_video_text', 'field_5cacef454182e'),
(220, 46, 'video_video_id', '5lWkZ-JaEOc'),
(221, 46, '_video_video_id', 'field_5cacef704182f'),
(222, 46, 'video', ''),
(223, 46, '_video', 'field_5cacef294182d'),
(224, 46, 'exp_exp_title', 'EXPERTISE'),
(225, 46, '_exp_exp_title', 'field_5cacf097b44ed'),
(226, 46, 'exp_exp_subtitle', 'Lorem ipsum dolor sit amet proin gravida nibh vel velit'),
(227, 46, '_exp_exp_subtitle', 'field_5cacf0ceb44ee'),
(228, 46, 'exp_exp_items_0_e_icon', '45'),
(229, 46, '_exp_exp_items_0_e_icon', 'field_5cacf0ffb44f0'),
(230, 46, 'exp_exp_items_0_e_title', 'WEB DESIGN & DEVELOPMENT'),
(231, 46, '_exp_exp_items_0_e_title', 'field_5cacf11eb44f1'),
(232, 46, 'exp_exp_items_0_e_text', 'This is Photoshop\'s version  of Lorem Ipsum. Proin gravida nibh vel velit auctor aliquet Aenean.'),
(233, 46, '_exp_exp_items_0_e_text', 'field_5cacf12cb44f2'),
(234, 46, 'exp_exp_items', '1'),
(235, 46, '_exp_exp_items', 'field_5cacf0deb44ef'),
(236, 46, 'exp', ''),
(237, 46, '_exp', 'field_5cacf082b44ec'),
(238, 47, 'home_banner_home_banner_image', '27'),
(239, 47, '_home_banner_home_banner_image', 'field_5cac7ce9a8c53'),
(240, 47, 'home_banner_home_banner_slides_0_slide_title', 'We Are Awesome Creative Agency'),
(241, 47, '_home_banner_home_banner_slides_0_slide_title', 'field_5cac7d27a8c55'),
(242, 47, 'home_banner_home_banner_slides_0_slide_text', 'This is Photoshop\'s version  of Lorem Ipsum. Proin gravida nibh vel velit auctor aliquet. Aenean sollicitudin, lorem quis bibendum auctor, nisi elit consequat ipsum, nec sagittis sem nibh id elit. Duis sed odio sit amet nibh vulputate cursus a sit amet mauris. Morbi accumsan ipsum velit.'),
(243, 47, '_home_banner_home_banner_slides_0_slide_text', 'field_5cac7d3da8c56'),
(244, 47, 'home_banner_home_banner_slides_0_slide_link', 'a:3:{s:5:\"title\";s:10:\"Learn more\";s:3:\"url\";s:1:\"#\";s:6:\"target\";s:0:\"\";}'),
(245, 47, '_home_banner_home_banner_slides_0_slide_link', 'field_5cac7d4ca8c57'),
(246, 47, 'home_banner_home_banner_slides', '4'),
(247, 47, '_home_banner_home_banner_slides', 'field_5cac7d05a8c54'),
(248, 47, 'home_banner', ''),
(249, 47, '_home_banner', 'field_5cac7caea8c52'),
(250, 47, 'home_banner_home_banner_slides_1_slide_title', 'We Are Awesome Creative Agency 2'),
(251, 47, '_home_banner_home_banner_slides_1_slide_title', 'field_5cac7d27a8c55'),
(252, 47, 'home_banner_home_banner_slides_1_slide_text', 'This is Photoshop\'s version  of Lorem Ipsum. Proin gravida nibh vel velit auctor aliquet. Aenean sollicitudin, lorem quis bibendum auctor, nisi elit consequat ipsum, nec sagittis sem nibh id elit. Duis sed odio sit amet nibh vulputate cursus a sit amet mauris. Morbi accumsan ipsum velit.'),
(253, 47, '_home_banner_home_banner_slides_1_slide_text', 'field_5cac7d3da8c56'),
(254, 47, 'home_banner_home_banner_slides_1_slide_link', 'a:3:{s:5:\"title\";s:6:\"Get it\";s:3:\"url\";s:1:\"#\";s:6:\"target\";s:0:\"\";}'),
(255, 47, '_home_banner_home_banner_slides_1_slide_link', 'field_5cac7d4ca8c57'),
(256, 47, 'home_banner_home_banner_slides_2_slide_title', 'We Are Awesome Creative Agency 3'),
(257, 47, '_home_banner_home_banner_slides_2_slide_title', 'field_5cac7d27a8c55'),
(258, 47, 'home_banner_home_banner_slides_2_slide_text', 'This is Photoshop\'s version  of Lorem Ipsum. Proin gravida nibh vel velit auctor aliquet. Aenean sollicitudin, lorem quis bibendum auctor, nisi elit consequat ipsum, nec sagittis sem nibh id elit. Duis sed odio sit amet nibh vulputate cursus a sit amet mauris. Morbi accumsan ipsum velit.'),
(259, 47, '_home_banner_home_banner_slides_2_slide_text', 'field_5cac7d3da8c56'),
(260, 47, 'home_banner_home_banner_slides_2_slide_link', 'a:3:{s:5:\"title\";s:10:\"Learn more\";s:3:\"url\";s:1:\"#\";s:6:\"target\";s:0:\"\";}'),
(261, 47, '_home_banner_home_banner_slides_2_slide_link', 'field_5cac7d4ca8c57'),
(262, 47, 'home_banner_home_banner_slides_3_slide_title', 'We Are Awesome Creative Agency 4'),
(263, 47, '_home_banner_home_banner_slides_3_slide_title', 'field_5cac7d27a8c55'),
(264, 47, 'home_banner_home_banner_slides_3_slide_text', 'This is Photoshop\'s version  of Lorem Ipsum. Proin gravida nibh vel velit auctor aliquet. Aenean sollicitudin, lorem quis bibendum auctor, nisi elit consequat ipsum, nec sagittis sem nibh id elit. Duis sed odio sit amet nibh vulputate cursus a sit amet mauris. Morbi accumsan ipsum velit.'),
(265, 47, '_home_banner_home_banner_slides_3_slide_text', 'field_5cac7d3da8c56'),
(266, 47, 'home_banner_home_banner_slides_3_slide_link', 'a:3:{s:5:\"title\";s:10:\"Learn more\";s:3:\"url\";s:1:\"#\";s:6:\"target\";s:0:\"\";}'),
(267, 47, '_home_banner_home_banner_slides_3_slide_link', 'field_5cac7d4ca8c57'),
(268, 47, 'story_story_image', '44'),
(269, 47, '_story_story_image', 'field_5cacdf3f00de1'),
(270, 47, 'story_story_text', 'This is Photoshop\'s version of Lorem Ipsum. Proin gravida nibh vel velit auctor aliquet. Aenean sollicitudin, lorem quis bibendum auctor, nisi elit consequat ipsum, nec sagittis sem nibh id elit. Duis sed odio sit amet nibh vulputate cursus\r\n\r\nMorbi accumsan ipsum velit. Nam nec tellus a odio tincidunt auctor a ornare odio. Sed non mauris vitae erat consequat auctor eu in elit. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos.'),
(271, 47, '_story_story_text', 'field_5cacdf6b00de2'),
(272, 47, 'story_link', 'a:3:{s:5:\"title\";s:0:\"\";s:3:\"url\";s:1:\"#\";s:6:\"target\";s:0:\"\";}'),
(273, 47, '_story_link', 'field_5cacef0cfd4d9'),
(274, 47, 'story', ''),
(275, 47, '_story', 'field_5cacdf3200de0'),
(276, 47, 'video_video_text', 'WATCH OUR STORY'),
(277, 47, '_video_video_text', 'field_5cacef454182e'),
(278, 47, 'video_video_id', '5lWkZ-JaEOc'),
(279, 47, '_video_video_id', 'field_5cacef704182f'),
(280, 47, 'video', ''),
(281, 47, '_video', 'field_5cacef294182d'),
(282, 47, 'exp_exp_title', 'EXPERTISE'),
(283, 47, '_exp_exp_title', 'field_5cacf097b44ed'),
(284, 47, 'exp_exp_subtitle', 'Lorem ipsum dolor sit amet proin gravida nibh vel velit'),
(285, 47, '_exp_exp_subtitle', 'field_5cacf0ceb44ee'),
(286, 47, 'exp_exp_items_0_e_icon', '45'),
(287, 47, '_exp_exp_items_0_e_icon', 'field_5cacf0ffb44f0'),
(288, 47, 'exp_exp_items_0_e_title', 'WEB DESIGN & DEVELOPMENT'),
(289, 47, '_exp_exp_items_0_e_title', 'field_5cacf11eb44f1'),
(290, 47, 'exp_exp_items_0_e_text', 'This is Photoshop\'s version  of Lorem Ipsum. Proin gravida nibh vel velit auctor aliquet Aenean.'),
(291, 47, '_exp_exp_items_0_e_text', 'field_5cacf12cb44f2'),
(292, 47, 'exp_exp_items', '1'),
(293, 47, '_exp_exp_items', 'field_5cacf0deb44ef'),
(294, 47, 'exp', ''),
(295, 47, '_exp', 'field_5cacf082b44ec'),
(296, 50, '_wp_attached_file', '2019/04/bg_i.png'),
(297, 50, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:1600;s:6:\"height\";i:550;s:4:\"file\";s:16:\"2019/04/bg_i.png\";s:5:\"sizes\";a:4:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:16:\"bg_i-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:6:\"medium\";a:4:{s:4:\"file\";s:16:\"bg_i-300x103.png\";s:5:\"width\";i:300;s:6:\"height\";i:103;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:16:\"bg_i-768x264.png\";s:5:\"width\";i:768;s:6:\"height\";i:264;s:9:\"mime-type\";s:9:\"image/png\";}s:5:\"large\";a:4:{s:4:\"file\";s:17:\"bg_i-1024x352.png\";s:5:\"width\";i:1024;s:6:\"height\";i:352;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(298, 6, 'story_story_title', 'Our story'),
(299, 6, '_story_story_title', 'field_5cadabdc2e2ef'),
(300, 6, 'video_video_image', '50'),
(301, 6, '_video_video_image', 'field_5cadb5178368a'),
(302, 51, 'home_banner_home_banner_image', '27'),
(303, 51, '_home_banner_home_banner_image', 'field_5cac7ce9a8c53'),
(304, 51, 'home_banner_home_banner_slides_0_slide_title', 'We Are Awesome Creative Agency'),
(305, 51, '_home_banner_home_banner_slides_0_slide_title', 'field_5cac7d27a8c55'),
(306, 51, 'home_banner_home_banner_slides_0_slide_text', 'This is Photoshop\'s version  of Lorem Ipsum. Proin gravida nibh vel velit auctor aliquet. Aenean sollicitudin, lorem quis bibendum auctor, nisi elit consequat ipsum, nec sagittis sem nibh id elit. Duis sed odio sit amet nibh vulputate cursus a sit amet mauris. Morbi accumsan ipsum velit.'),
(307, 51, '_home_banner_home_banner_slides_0_slide_text', 'field_5cac7d3da8c56'),
(308, 51, 'home_banner_home_banner_slides_0_slide_link', 'a:3:{s:5:\"title\";s:10:\"Learn more\";s:3:\"url\";s:1:\"#\";s:6:\"target\";s:0:\"\";}'),
(309, 51, '_home_banner_home_banner_slides_0_slide_link', 'field_5cac7d4ca8c57'),
(310, 51, 'home_banner_home_banner_slides', '4'),
(311, 51, '_home_banner_home_banner_slides', 'field_5cac7d05a8c54'),
(312, 51, 'home_banner', ''),
(313, 51, '_home_banner', 'field_5cac7caea8c52'),
(314, 51, 'home_banner_home_banner_slides_1_slide_title', 'We Are Awesome Creative Agency 2'),
(315, 51, '_home_banner_home_banner_slides_1_slide_title', 'field_5cac7d27a8c55'),
(316, 51, 'home_banner_home_banner_slides_1_slide_text', 'This is Photoshop\'s version  of Lorem Ipsum. Proin gravida nibh vel velit auctor aliquet. Aenean sollicitudin, lorem quis bibendum auctor, nisi elit consequat ipsum, nec sagittis sem nibh id elit. Duis sed odio sit amet nibh vulputate cursus a sit amet mauris. Morbi accumsan ipsum velit.'),
(317, 51, '_home_banner_home_banner_slides_1_slide_text', 'field_5cac7d3da8c56'),
(318, 51, 'home_banner_home_banner_slides_1_slide_link', 'a:3:{s:5:\"title\";s:6:\"Get it\";s:3:\"url\";s:1:\"#\";s:6:\"target\";s:0:\"\";}'),
(319, 51, '_home_banner_home_banner_slides_1_slide_link', 'field_5cac7d4ca8c57'),
(320, 51, 'home_banner_home_banner_slides_2_slide_title', 'We Are Awesome Creative Agency 3'),
(321, 51, '_home_banner_home_banner_slides_2_slide_title', 'field_5cac7d27a8c55'),
(322, 51, 'home_banner_home_banner_slides_2_slide_text', 'This is Photoshop\'s version  of Lorem Ipsum. Proin gravida nibh vel velit auctor aliquet. Aenean sollicitudin, lorem quis bibendum auctor, nisi elit consequat ipsum, nec sagittis sem nibh id elit. Duis sed odio sit amet nibh vulputate cursus a sit amet mauris. Morbi accumsan ipsum velit.'),
(323, 51, '_home_banner_home_banner_slides_2_slide_text', 'field_5cac7d3da8c56'),
(324, 51, 'home_banner_home_banner_slides_2_slide_link', 'a:3:{s:5:\"title\";s:10:\"Learn more\";s:3:\"url\";s:1:\"#\";s:6:\"target\";s:0:\"\";}'),
(325, 51, '_home_banner_home_banner_slides_2_slide_link', 'field_5cac7d4ca8c57'),
(326, 51, 'home_banner_home_banner_slides_3_slide_title', 'We Are Awesome Creative Agency 4'),
(327, 51, '_home_banner_home_banner_slides_3_slide_title', 'field_5cac7d27a8c55'),
(328, 51, 'home_banner_home_banner_slides_3_slide_text', 'This is Photoshop\'s version  of Lorem Ipsum. Proin gravida nibh vel velit auctor aliquet. Aenean sollicitudin, lorem quis bibendum auctor, nisi elit consequat ipsum, nec sagittis sem nibh id elit. Duis sed odio sit amet nibh vulputate cursus a sit amet mauris. Morbi accumsan ipsum velit.'),
(329, 51, '_home_banner_home_banner_slides_3_slide_text', 'field_5cac7d3da8c56'),
(330, 51, 'home_banner_home_banner_slides_3_slide_link', 'a:3:{s:5:\"title\";s:10:\"Learn more\";s:3:\"url\";s:1:\"#\";s:6:\"target\";s:0:\"\";}'),
(331, 51, '_home_banner_home_banner_slides_3_slide_link', 'field_5cac7d4ca8c57'),
(332, 51, 'story_story_image', '44'),
(333, 51, '_story_story_image', 'field_5cacdf3f00de1'),
(334, 51, 'story_story_text', 'This is Photoshop\'s version of Lorem Ipsum. Proin gravida nibh vel velit auctor aliquet. Aenean sollicitudin, lorem quis bibendum auctor, nisi elit consequat ipsum, nec sagittis sem nibh id elit. Duis sed odio sit amet nibh vulputate cursus\r\n\r\nMorbi accumsan ipsum velit. Nam nec tellus a odio tincidunt auctor a ornare odio. Sed non mauris vitae erat consequat auctor eu in elit. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos.'),
(335, 51, '_story_story_text', 'field_5cacdf6b00de2'),
(336, 51, 'story_link', 'a:3:{s:5:\"title\";s:0:\"\";s:3:\"url\";s:1:\"#\";s:6:\"target\";s:0:\"\";}'),
(337, 51, '_story_link', 'field_5cacef0cfd4d9'),
(338, 51, 'story', ''),
(339, 51, '_story', 'field_5cacdf3200de0'),
(340, 51, 'video_video_text', 'WATCH OUR STORY'),
(341, 51, '_video_video_text', 'field_5cacef454182e'),
(342, 51, 'video_video_id', '5lWkZ-JaEOc'),
(343, 51, '_video_video_id', 'field_5cacef704182f'),
(344, 51, 'video', ''),
(345, 51, '_video', 'field_5cacef294182d'),
(346, 51, 'exp_exp_title', 'EXPERTISE'),
(347, 51, '_exp_exp_title', 'field_5cacf097b44ed'),
(348, 51, 'exp_exp_subtitle', 'Lorem ipsum dolor sit amet proin gravida nibh vel velit'),
(349, 51, '_exp_exp_subtitle', 'field_5cacf0ceb44ee'),
(350, 51, 'exp_exp_items_0_e_icon', '45'),
(351, 51, '_exp_exp_items_0_e_icon', 'field_5cacf0ffb44f0'),
(352, 51, 'exp_exp_items_0_e_title', 'WEB DESIGN & DEVELOPMENT'),
(353, 51, '_exp_exp_items_0_e_title', 'field_5cacf11eb44f1'),
(354, 51, 'exp_exp_items_0_e_text', 'This is Photoshop\'s version  of Lorem Ipsum. Proin gravida nibh vel velit auctor aliquet Aenean.'),
(355, 51, '_exp_exp_items_0_e_text', 'field_5cacf12cb44f2'),
(356, 51, 'exp_exp_items', '1'),
(357, 51, '_exp_exp_items', 'field_5cacf0deb44ef'),
(358, 51, 'exp', ''),
(359, 51, '_exp', 'field_5cacf082b44ec'),
(360, 51, 'story_story_title', 'Our story'),
(361, 51, '_story_story_title', 'field_5cadabdc2e2ef'),
(362, 51, 'video_video_image', '50'),
(363, 51, '_video_video_image', 'field_5cadb5178368a'),
(364, 52, '_wp_attached_file', '2019/04/ic_2.png'),
(365, 52, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:50;s:6:\"height\";i:42;s:4:\"file\";s:16:\"2019/04/ic_2.png\";s:5:\"sizes\";a:0:{}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(366, 53, '_wp_attached_file', '2019/04/ic_3.png'),
(367, 53, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:28;s:6:\"height\";i:50;s:4:\"file\";s:16:\"2019/04/ic_3.png\";s:5:\"sizes\";a:0:{}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(368, 54, '_wp_attached_file', '2019/04/ic_4.png'),
(369, 54, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:50;s:6:\"height\";i:50;s:4:\"file\";s:16:\"2019/04/ic_4.png\";s:5:\"sizes\";a:0:{}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(370, 55, '_wp_attached_file', '2019/04/ic_5.png'),
(371, 55, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:41;s:6:\"height\";i:50;s:4:\"file\";s:16:\"2019/04/ic_5.png\";s:5:\"sizes\";a:0:{}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(372, 56, '_wp_attached_file', '2019/04/ic_6.png'),
(373, 56, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:50;s:6:\"height\";i:46;s:4:\"file\";s:16:\"2019/04/ic_6.png\";s:5:\"sizes\";a:0:{}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(374, 6, 'exp_exp_items_1_e_icon', '52'),
(375, 6, '_exp_exp_items_1_e_icon', 'field_5cacf0ffb44f0'),
(376, 6, 'exp_exp_items_1_e_title', 'BRANDING IDENTITY'),
(377, 6, '_exp_exp_items_1_e_title', 'field_5cacf11eb44f1'),
(378, 6, 'exp_exp_items_1_e_text', 'This is Photoshop\'s version  of Lorem Ipsum. Proin gravida nibh vel velit auctor aliquet Aenean.'),
(379, 6, '_exp_exp_items_1_e_text', 'field_5cacf12cb44f2'),
(380, 6, 'exp_exp_items_2_e_icon', '53'),
(381, 6, '_exp_exp_items_2_e_icon', 'field_5cacf0ffb44f0'),
(382, 6, 'exp_exp_items_2_e_title', 'MOBILE APP'),
(383, 6, '_exp_exp_items_2_e_title', 'field_5cacf11eb44f1'),
(384, 6, 'exp_exp_items_2_e_text', 'This is Photoshop\'s version  of Lorem Ipsum. Proin gravida nibh vel velit auctor aliquet Aenean.'),
(385, 6, '_exp_exp_items_2_e_text', 'field_5cacf12cb44f2'),
(386, 6, 'exp_exp_items_3_e_icon', '54'),
(387, 6, '_exp_exp_items_3_e_icon', 'field_5cacf0ffb44f0'),
(388, 6, 'exp_exp_items_3_e_title', 'SEARCH ENGINE OPTIMIZATION'),
(389, 6, '_exp_exp_items_3_e_title', 'field_5cacf11eb44f1'),
(390, 6, 'exp_exp_items_3_e_text', 'This is Photoshop\'s version  of Lorem Ipsum. Proin gravida nibh vel velit auctor aliquet Aenean.'),
(391, 6, '_exp_exp_items_3_e_text', 'field_5cacf12cb44f2'),
(392, 6, 'exp_exp_items_4_e_icon', '55'),
(393, 6, '_exp_exp_items_4_e_icon', 'field_5cacf0ffb44f0'),
(394, 6, 'exp_exp_items_4_e_title', 'GAME DEVELOPMENT'),
(395, 6, '_exp_exp_items_4_e_title', 'field_5cacf11eb44f1'),
(396, 6, 'exp_exp_items_4_e_text', 'This is Photoshop\'s version  of Lorem Ipsum. Proin gravida nibh vel velit auctor aliquet Aenean.'),
(397, 6, '_exp_exp_items_4_e_text', 'field_5cacf12cb44f2'),
(398, 6, 'exp_exp_items_5_e_icon', '56'),
(399, 6, '_exp_exp_items_5_e_icon', 'field_5cacf0ffb44f0'),
(400, 6, 'exp_exp_items_5_e_title', 'MADE WITH LOVE'),
(401, 6, '_exp_exp_items_5_e_title', 'field_5cacf11eb44f1'),
(402, 6, 'exp_exp_items_5_e_text', 'This is Photoshop\'s version  of Lorem Ipsum. Proin gravida nibh vel velit auctor aliquet Aenean.'),
(403, 6, '_exp_exp_items_5_e_text', 'field_5cacf12cb44f2'),
(404, 57, 'home_banner_home_banner_image', '27'),
(405, 57, '_home_banner_home_banner_image', 'field_5cac7ce9a8c53'),
(406, 57, 'home_banner_home_banner_slides_0_slide_title', 'We Are Awesome Creative Agency'),
(407, 57, '_home_banner_home_banner_slides_0_slide_title', 'field_5cac7d27a8c55'),
(408, 57, 'home_banner_home_banner_slides_0_slide_text', 'This is Photoshop\'s version  of Lorem Ipsum. Proin gravida nibh vel velit auctor aliquet. Aenean sollicitudin, lorem quis bibendum auctor, nisi elit consequat ipsum, nec sagittis sem nibh id elit. Duis sed odio sit amet nibh vulputate cursus a sit amet mauris. Morbi accumsan ipsum velit.'),
(409, 57, '_home_banner_home_banner_slides_0_slide_text', 'field_5cac7d3da8c56'),
(410, 57, 'home_banner_home_banner_slides_0_slide_link', 'a:3:{s:5:\"title\";s:10:\"Learn more\";s:3:\"url\";s:1:\"#\";s:6:\"target\";s:0:\"\";}'),
(411, 57, '_home_banner_home_banner_slides_0_slide_link', 'field_5cac7d4ca8c57'),
(412, 57, 'home_banner_home_banner_slides', '4'),
(413, 57, '_home_banner_home_banner_slides', 'field_5cac7d05a8c54'),
(414, 57, 'home_banner', ''),
(415, 57, '_home_banner', 'field_5cac7caea8c52'),
(416, 57, 'home_banner_home_banner_slides_1_slide_title', 'We Are Awesome Creative Agency 2'),
(417, 57, '_home_banner_home_banner_slides_1_slide_title', 'field_5cac7d27a8c55'),
(418, 57, 'home_banner_home_banner_slides_1_slide_text', 'This is Photoshop\'s version  of Lorem Ipsum. Proin gravida nibh vel velit auctor aliquet. Aenean sollicitudin, lorem quis bibendum auctor, nisi elit consequat ipsum, nec sagittis sem nibh id elit. Duis sed odio sit amet nibh vulputate cursus a sit amet mauris. Morbi accumsan ipsum velit.'),
(419, 57, '_home_banner_home_banner_slides_1_slide_text', 'field_5cac7d3da8c56'),
(420, 57, 'home_banner_home_banner_slides_1_slide_link', 'a:3:{s:5:\"title\";s:6:\"Get it\";s:3:\"url\";s:1:\"#\";s:6:\"target\";s:0:\"\";}'),
(421, 57, '_home_banner_home_banner_slides_1_slide_link', 'field_5cac7d4ca8c57'),
(422, 57, 'home_banner_home_banner_slides_2_slide_title', 'We Are Awesome Creative Agency 3'),
(423, 57, '_home_banner_home_banner_slides_2_slide_title', 'field_5cac7d27a8c55'),
(424, 57, 'home_banner_home_banner_slides_2_slide_text', 'This is Photoshop\'s version  of Lorem Ipsum. Proin gravida nibh vel velit auctor aliquet. Aenean sollicitudin, lorem quis bibendum auctor, nisi elit consequat ipsum, nec sagittis sem nibh id elit. Duis sed odio sit amet nibh vulputate cursus a sit amet mauris. Morbi accumsan ipsum velit.'),
(425, 57, '_home_banner_home_banner_slides_2_slide_text', 'field_5cac7d3da8c56'),
(426, 57, 'home_banner_home_banner_slides_2_slide_link', 'a:3:{s:5:\"title\";s:10:\"Learn more\";s:3:\"url\";s:1:\"#\";s:6:\"target\";s:0:\"\";}'),
(427, 57, '_home_banner_home_banner_slides_2_slide_link', 'field_5cac7d4ca8c57'),
(428, 57, 'home_banner_home_banner_slides_3_slide_title', 'We Are Awesome Creative Agency 4'),
(429, 57, '_home_banner_home_banner_slides_3_slide_title', 'field_5cac7d27a8c55'),
(430, 57, 'home_banner_home_banner_slides_3_slide_text', 'This is Photoshop\'s version  of Lorem Ipsum. Proin gravida nibh vel velit auctor aliquet. Aenean sollicitudin, lorem quis bibendum auctor, nisi elit consequat ipsum, nec sagittis sem nibh id elit. Duis sed odio sit amet nibh vulputate cursus a sit amet mauris. Morbi accumsan ipsum velit.'),
(431, 57, '_home_banner_home_banner_slides_3_slide_text', 'field_5cac7d3da8c56'),
(432, 57, 'home_banner_home_banner_slides_3_slide_link', 'a:3:{s:5:\"title\";s:10:\"Learn more\";s:3:\"url\";s:1:\"#\";s:6:\"target\";s:0:\"\";}'),
(433, 57, '_home_banner_home_banner_slides_3_slide_link', 'field_5cac7d4ca8c57'),
(434, 57, 'story_story_image', '44'),
(435, 57, '_story_story_image', 'field_5cacdf3f00de1'),
(436, 57, 'story_story_text', 'This is Photoshop\'s version of Lorem Ipsum. Proin gravida nibh vel velit auctor aliquet. Aenean sollicitudin, lorem quis bibendum auctor, nisi elit consequat ipsum, nec sagittis sem nibh id elit. Duis sed odio sit amet nibh vulputate cursus\r\n\r\nMorbi accumsan ipsum velit. Nam nec tellus a odio tincidunt auctor a ornare odio. Sed non mauris vitae erat consequat auctor eu in elit. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos.'),
(437, 57, '_story_story_text', 'field_5cacdf6b00de2'),
(438, 57, 'story_link', 'a:3:{s:5:\"title\";s:0:\"\";s:3:\"url\";s:1:\"#\";s:6:\"target\";s:0:\"\";}'),
(439, 57, '_story_link', 'field_5cacef0cfd4d9'),
(440, 57, 'story', ''),
(441, 57, '_story', 'field_5cacdf3200de0'),
(442, 57, 'video_video_text', 'WATCH OUR STORY'),
(443, 57, '_video_video_text', 'field_5cacef454182e'),
(444, 57, 'video_video_id', '5lWkZ-JaEOc'),
(445, 57, '_video_video_id', 'field_5cacef704182f'),
(446, 57, 'video', ''),
(447, 57, '_video', 'field_5cacef294182d'),
(448, 57, 'exp_exp_title', 'EXPERTISE'),
(449, 57, '_exp_exp_title', 'field_5cacf097b44ed'),
(450, 57, 'exp_exp_subtitle', 'Lorem ipsum dolor sit amet proin gravida nibh vel velit'),
(451, 57, '_exp_exp_subtitle', 'field_5cacf0ceb44ee'),
(452, 57, 'exp_exp_items_0_e_icon', '45'),
(453, 57, '_exp_exp_items_0_e_icon', 'field_5cacf0ffb44f0'),
(454, 57, 'exp_exp_items_0_e_title', 'WEB DESIGN & DEVELOPMENT'),
(455, 57, '_exp_exp_items_0_e_title', 'field_5cacf11eb44f1'),
(456, 57, 'exp_exp_items_0_e_text', 'This is Photoshop\'s version  of Lorem Ipsum. Proin gravida nibh vel velit auctor aliquet Aenean.'),
(457, 57, '_exp_exp_items_0_e_text', 'field_5cacf12cb44f2'),
(458, 57, 'exp_exp_items', '6'),
(459, 57, '_exp_exp_items', 'field_5cacf0deb44ef'),
(460, 57, 'exp', ''),
(461, 57, '_exp', 'field_5cacf082b44ec'),
(462, 57, 'story_story_title', 'Our story'),
(463, 57, '_story_story_title', 'field_5cadabdc2e2ef'),
(464, 57, 'video_video_image', '50'),
(465, 57, '_video_video_image', 'field_5cadb5178368a'),
(466, 57, 'exp_exp_items_1_e_icon', '52'),
(467, 57, '_exp_exp_items_1_e_icon', 'field_5cacf0ffb44f0'),
(468, 57, 'exp_exp_items_1_e_title', 'BRANDING IDENTITY'),
(469, 57, '_exp_exp_items_1_e_title', 'field_5cacf11eb44f1'),
(470, 57, 'exp_exp_items_1_e_text', 'This is Photoshop\'s version  of Lorem Ipsum. Proin gravida nibh vel velit auctor aliquet Aenean.'),
(471, 57, '_exp_exp_items_1_e_text', 'field_5cacf12cb44f2'),
(472, 57, 'exp_exp_items_2_e_icon', '53'),
(473, 57, '_exp_exp_items_2_e_icon', 'field_5cacf0ffb44f0'),
(474, 57, 'exp_exp_items_2_e_title', 'MOBILE APP'),
(475, 57, '_exp_exp_items_2_e_title', 'field_5cacf11eb44f1'),
(476, 57, 'exp_exp_items_2_e_text', 'This is Photoshop\'s version  of Lorem Ipsum. Proin gravida nibh vel velit auctor aliquet Aenean.'),
(477, 57, '_exp_exp_items_2_e_text', 'field_5cacf12cb44f2'),
(478, 57, 'exp_exp_items_3_e_icon', '54'),
(479, 57, '_exp_exp_items_3_e_icon', 'field_5cacf0ffb44f0'),
(480, 57, 'exp_exp_items_3_e_title', 'SEARCH ENGINE OPTIMIZATION'),
(481, 57, '_exp_exp_items_3_e_title', 'field_5cacf11eb44f1'),
(482, 57, 'exp_exp_items_3_e_text', 'This is Photoshop\'s version  of Lorem Ipsum. Proin gravida nibh vel velit auctor aliquet Aenean.'),
(483, 57, '_exp_exp_items_3_e_text', 'field_5cacf12cb44f2'),
(484, 57, 'exp_exp_items_4_e_icon', '55'),
(485, 57, '_exp_exp_items_4_e_icon', 'field_5cacf0ffb44f0'),
(486, 57, 'exp_exp_items_4_e_title', 'GAME DEVELOPMENT'),
(487, 57, '_exp_exp_items_4_e_title', 'field_5cacf11eb44f1'),
(488, 57, 'exp_exp_items_4_e_text', 'This is Photoshop\'s version  of Lorem Ipsum. Proin gravida nibh vel velit auctor aliquet Aenean.'),
(489, 57, '_exp_exp_items_4_e_text', 'field_5cacf12cb44f2'),
(490, 57, 'exp_exp_items_5_e_icon', '56'),
(491, 57, '_exp_exp_items_5_e_icon', 'field_5cacf0ffb44f0'),
(492, 57, 'exp_exp_items_5_e_title', 'MADE WITH LOVE'),
(493, 57, '_exp_exp_items_5_e_title', 'field_5cacf11eb44f1'),
(494, 57, 'exp_exp_items_5_e_text', 'This is Photoshop\'s version  of Lorem Ipsum. Proin gravida nibh vel velit auctor aliquet Aenean.'),
(495, 57, '_exp_exp_items_5_e_text', 'field_5cacf12cb44f2'),
(496, 2, '_wp_trash_meta_status', 'publish'),
(497, 2, '_wp_trash_meta_time', '1554895436'),
(498, 2, '_wp_desired_post_slug', 'sample-page'),
(499, 59, '_edit_lock', '1554897900:1'),
(500, 60, '_menu_item_type', 'custom'),
(501, 60, '_menu_item_menu_item_parent', '0'),
(502, 60, '_menu_item_object_id', '60'),
(503, 60, '_menu_item_object', 'custom'),
(504, 60, '_menu_item_target', ''),
(505, 60, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(506, 60, '_menu_item_xfn', ''),
(507, 60, '_menu_item_url', '#'),
(508, 61, '_menu_item_type', 'custom'),
(509, 61, '_menu_item_menu_item_parent', '0'),
(510, 61, '_menu_item_object_id', '61'),
(511, 61, '_menu_item_object', 'custom'),
(512, 61, '_menu_item_target', ''),
(513, 61, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(514, 61, '_menu_item_xfn', ''),
(515, 61, '_menu_item_url', '#'),
(516, 62, '_menu_item_type', 'custom'),
(517, 62, '_menu_item_menu_item_parent', '0'),
(518, 62, '_menu_item_object_id', '62'),
(519, 62, '_menu_item_object', 'custom'),
(520, 62, '_menu_item_target', ''),
(521, 62, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(522, 62, '_menu_item_xfn', ''),
(523, 62, '_menu_item_url', '#'),
(524, 59, '_wp_trash_meta_status', 'publish'),
(525, 59, '_wp_trash_meta_time', '1554897952'),
(526, 63, '_wp_trash_meta_status', 'publish'),
(527, 63, '_wp_trash_meta_time', '1554898990'),
(528, 64, '_edit_lock', '1554899984:1'),
(529, 64, '_wp_trash_meta_status', 'publish'),
(530, 64, '_wp_trash_meta_time', '1554899984'),
(531, 65, '_wp_trash_meta_status', 'publish'),
(532, 65, '_wp_trash_meta_time', '1554975702');

-- --------------------------------------------------------

--
-- Table structure for table `wp_posts`
--

CREATE TABLE `wp_posts` (
  `ID` bigint(20) UNSIGNED NOT NULL,
  `post_author` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_title` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_excerpt` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'open',
  `post_password` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `post_name` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `to_ping` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `pinged` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_parent` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `guid` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `menu_order` int(11) NOT NULL DEFAULT '0',
  `post_type` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_count` bigint(20) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Dumping data for table `wp_posts`
--

INSERT INTO `wp_posts` (`ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(1, 1, '2019-04-09 11:42:50', '2019-04-09 08:42:50', '<!-- wp:paragraph -->\n<p>Добро пожаловать в WordPress. Это ваша первая запись. Отредактируйте или удалите ее, затем начинайте создавать!</p>\n<!-- /wp:paragraph -->', 'Привет, мир!', '', 'publish', 'open', 'open', '', '%d0%bf%d1%80%d0%b8%d0%b2%d0%b5%d1%82-%d0%bc%d0%b8%d1%80', '', '', '2019-04-09 11:42:50', '2019-04-09 08:42:50', '', 0, 'http://localhost:8888/tajam/?p=1', 0, 'post', '', 1),
(2, 1, '2019-04-09 11:42:50', '2019-04-09 08:42:50', '<!-- wp:paragraph -->\n<p>Это пример страницы. От записей в блоге она отличается тем, что остаётся на одном месте и отображается в меню сайта (в большинстве тем). На странице &laquo;Детали&raquo; владельцы сайтов обычно рассказывают о себе потенциальным посетителям. Например, так:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:quote -->\n<blockquote class=\"wp-block-quote\"><p>Привет! Днём я курьер, а вечером &#8212; подающий надежды актёр. Это мой блог. Я живу в Ростове-на-Дону, люблю своего пса Джека и пинаколаду. (И ещё попадать под дождь.)</p></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:paragraph -->\n<p>...или так:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:quote -->\n<blockquote class=\"wp-block-quote\"><p>Компания &laquo;Штучки XYZ&raquo; была основана в 1971 году и с тех пор производит качественные штучки. Компания находится в Готэм-сити, имеет штат из более чем 2000 сотрудников и приносит много пользы жителям Готэма.</p></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:paragraph -->\n<p>Перейдите <a href=\"http://localhost:8888/tajam/wp-admin/\">в консоль</a>, чтобы удалить эту страницу и создать новые. Успехов!</p>\n<!-- /wp:paragraph -->', 'Пример страницы', '', 'trash', 'closed', 'open', '', 'sample-page__trashed', '', '', '2019-04-10 14:23:56', '2019-04-10 11:23:56', '', 0, 'http://localhost:8888/tajam/?page_id=2', 0, 'page', '', 0),
(3, 1, '2019-04-09 11:42:50', '2019-04-09 08:42:50', '<!-- wp:heading --><h2>Кто мы</h2><!-- /wp:heading --><!-- wp:paragraph --><p>Наш адрес сайта: http://localhost:8888/tajam.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Какие персональные данные мы собираем и с какой целью</h2><!-- /wp:heading --><!-- wp:heading {\"level\":3} --><h3>Комментарии</h3><!-- /wp:heading --><!-- wp:paragraph --><p>Если посетитель оставляет комментарий на сайте, мы собираем данные указанные в форме комментария, а также IP адрес посетителя и данные user-agent браузера с целью определения спама.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>Анонимизированная строка создаваемая из вашего адреса email (\"хеш\") может предоставляться сервису Gravatar, чтобы определить используете ли вы его. Политика конфиденциальности Gravatar доступна здесь: https://automattic.com/privacy/ . После одобрения комментария ваше изображение профиля будет видимым публично в контексте вашего комментария.</p><!-- /wp:paragraph --><!-- wp:heading {\"level\":3} --><h3>Медиафайлы</h3><!-- /wp:heading --><!-- wp:paragraph --><p>Если вы зарегистрированный пользователь и загружаете фотографии на сайт, вам возможно следует избегать загрузки изображений с метаданными EXIF, так как они могут содержать данные вашего месторасположения по GPS. Посетители могут извлечь эту информацию скачав изображения с сайта.</p><!-- /wp:paragraph --><!-- wp:heading {\"level\":3} --><h3>Формы контактов</h3><!-- /wp:heading --><!-- wp:heading {\"level\":3} --><h3>Куки</h3><!-- /wp:heading --><!-- wp:paragraph --><p>Если вы оставляете комментарий на нашем сайте, вы можете включить сохранение вашего имени, адреса email и вебсайта в куки. Это делается для вашего удобства, чтобы не заполнять данные снова при повторном комментировании. Эти куки хранятся в течение одного года.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>Если у вас есть учетная запись на сайте и вы войдете в неё, мы установим временный куки для определения поддержки куки вашим браузером, куки не содержит никакой личной информации и удаляется при закрытии вашего браузера.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>При входе в учетную запись мы также устанавливаем несколько куки с данными входа и настройками экрана. Куки входа хранятся в течение двух дней, куки с настройками экрана - год. Если вы выберете возможность \"Запомнить меня\", данные о входе будут сохраняться в течение двух недель. При выходе из учетной записи куки входа будут удалены.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>При редактировании или публикации статьи в браузере будет сохранен дополнительный куки, он не содержит персональных данных и содержит только ID записи отредактированной вами, истекает через 1 день.</p><!-- /wp:paragraph --><!-- wp:heading {\"level\":3} --><h3>Встраиваемое содержимое других вебсайтов</h3><!-- /wp:heading --><!-- wp:paragraph --><p>Статьи на этом сайте могут включать встраиваемое содержимое (например видео, изображения, статьи и др.), подобное содержимое ведет себя так же, как если бы посетитель зашел на другой сайт.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>Эти сайты могут собирать данные о вас, использовать куки, внедрять дополнительное отслеживание третьей стороной и следить за вашим взаимодействием с внедренным содержимым, включая отслеживание взаимодействия, если у вас есть учетная запись и вы авторизовались на том сайте.</p><!-- /wp:paragraph --><!-- wp:heading {\"level\":3} --><h3>Веб-аналитика</h3><!-- /wp:heading --><!-- wp:heading --><h2>С кем мы делимся вашими данными</h2><!-- /wp:heading --><!-- wp:heading --><h2>Как долго мы храним ваши данные</h2><!-- /wp:heading --><!-- wp:paragraph --><p>Если вы оставляете комментарий, то сам комментарий и его метаданные сохраняются неопределенно долго. Это делается для того, чтобы определять и одобрять последующие комментарии автоматически, вместо помещения их в очередь на одобрение.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>Для пользователей с регистрацией на нашем сайте мы храним ту личную информацию, которую они указывают в своем профиле. Все пользователи могут видеть, редактировать или удалить свою информацию из профиля в любое время (кроме имени пользователя). Администрация вебсайта также может видеть и изменять эту информацию.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Какие у вас права на ваши данные</h2><!-- /wp:heading --><!-- wp:paragraph --><p>При наличии учетной записи на сайте или если вы оставляли комментарии, то вы можете запросить файл экспорта персональных данных, которые мы сохранили о вас, включая предоставленные вами данные. Вы также можете запросить удаление этих данных, это не включает данные, которые мы обязаны хранить в административных целях, по закону или целях безопасности.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Куда мы отправляем ваши данные</h2><!-- /wp:heading --><!-- wp:paragraph --><p>Комментарии пользователей могут проверяться автоматическим сервисом определения спама.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Ваша контактная информация</h2><!-- /wp:heading --><!-- wp:heading --><h2>Дополнительная информация</h2><!-- /wp:heading --><!-- wp:heading {\"level\":3} --><h3>Как мы защищаем ваши данные</h3><!-- /wp:heading --><!-- wp:heading {\"level\":3} --><h3>Какие принимаются процедуры против взлома данных</h3><!-- /wp:heading --><!-- wp:heading {\"level\":3} --><h3>От каких третьих сторон мы получаем данные</h3><!-- /wp:heading --><!-- wp:heading {\"level\":3} --><h3>Какие автоматические решения принимаются на основе данных пользователей</h3><!-- /wp:heading --><!-- wp:heading {\"level\":3} --><h3>Требования к раскрытию отраслевых нормативных требований</h3><!-- /wp:heading -->', 'Политика конфиденциальности', '', 'draft', 'closed', 'open', '', 'privacy-policy', '', '', '2019-04-09 11:42:50', '2019-04-09 08:42:50', '', 0, 'http://localhost:8888/tajam/?page_id=3', 0, 'page', '', 0),
(4, 1, '2019-04-09 11:43:01', '0000-00-00 00:00:00', '', 'Черновик', '', 'auto-draft', 'open', 'open', '', '', '', '', '2019-04-09 11:43:01', '0000-00-00 00:00:00', '', 0, 'http://localhost:8888/tajam/?p=4', 0, 'post', '', 0),
(5, 1, '2019-04-09 11:44:36', '0000-00-00 00:00:00', '', 'Черновик', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2019-04-09 11:44:36', '0000-00-00 00:00:00', '', 0, 'http://localhost:8888/tajam/?page_id=5', 0, 'page', '', 0),
(6, 1, '2019-04-09 11:46:53', '2019-04-09 08:46:53', '', 'Home', '', 'publish', 'closed', 'closed', '', 'home', '', '', '2019-04-10 16:35:59', '2019-04-10 13:35:59', '', 0, 'http://localhost:8888/tajam/?page_id=6', 0, 'page', '', 0),
(7, 1, '2019-04-09 11:46:53', '2019-04-09 08:46:53', '', 'Home', '', 'inherit', 'closed', 'closed', '', '6-revision-v1', '', '', '2019-04-09 11:46:53', '2019-04-09 08:46:53', '', 6, 'http://localhost:8888/tajam/2019/04/09/6-revision-v1/', 0, 'revision', '', 0),
(8, 1, '2019-04-09 13:03:37', '2019-04-09 10:03:37', '', 'logo', '', 'inherit', 'open', 'closed', '', 'logo', '', '', '2019-04-09 13:03:37', '2019-04-09 10:03:37', '', 0, 'http://localhost:8888/tajam/wp-content/uploads/2019/04/logo.png', 0, 'attachment', 'image/png', 0),
(9, 1, '2019-04-09 13:04:06', '0000-00-00 00:00:00', '{\n    \"tajam::logo_image\": {\n        \"value\": \"http://localhost:8888/tajam/wp-content/uploads/2019/04/logo.png\",\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2019-04-09 10:04:06\"\n    }\n}', '', '', 'auto-draft', 'closed', 'closed', '', 'e5c915b2-076e-4ea5-9167-5f6dd34bfd6a', '', '', '2019-04-09 13:04:06', '0000-00-00 00:00:00', '', 0, 'http://localhost:8888/tajam/?p=9', 0, 'customize_changeset', '', 0),
(10, 1, '2019-04-09 13:08:30', '2019-04-09 10:08:30', '{\n    \"tajam::logo_image\": {\n        \"value\": \"http://localhost:8888/tajam/wp-content/uploads/2019/04/logo.png\",\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2019-04-09 10:08:30\"\n    }\n}', '', '', 'trash', 'closed', 'closed', '', 'be52e827-ce40-4f43-8c59-d442a5c5c165', '', '', '2019-04-09 13:08:30', '2019-04-09 10:08:30', '', 0, 'http://localhost:8888/tajam/2019/04/09/be52e827-ce40-4f43-8c59-d442a5c5c165/', 0, 'customize_changeset', '', 0),
(11, 1, '2019-04-09 13:29:19', '2019-04-09 10:29:19', '{\n    \"tajam::nav_menu_locations[header]\": {\n        \"value\": -5664243205556818000,\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2019-04-09 10:27:04\"\n    },\n    \"nav_menu[-5664243205556818000]\": {\n        \"value\": {\n            \"name\": \"Header menu\",\n            \"description\": \"\",\n            \"parent\": 0,\n            \"auto_add\": false\n        },\n        \"type\": \"nav_menu\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2019-04-09 10:27:04\"\n    },\n    \"nav_menu_item[-4658288802541470000]\": {\n        \"value\": false,\n        \"type\": \"nav_menu_item\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2019-04-09 10:29:18\"\n    },\n    \"nav_menu_item[-3166271988598358000]\": {\n        \"value\": {\n            \"object_id\": 0,\n            \"object\": \"custom\",\n            \"menu_item_parent\": 0,\n            \"position\": 2,\n            \"type\": \"custom\",\n            \"title\": \"About\",\n            \"url\": \"#\",\n            \"target\": \"\",\n            \"attr_title\": \"\",\n            \"description\": \"\",\n            \"classes\": \"\",\n            \"xfn\": \"\",\n            \"status\": \"publish\",\n            \"original_title\": \"About\",\n            \"nav_menu_term_id\": -5664243205556818000,\n            \"_invalid\": false,\n            \"type_label\": \"\\u041f\\u0440\\u043e\\u0438\\u0437\\u0432\\u043e\\u043b\\u044c\\u043d\\u0430\\u044f \\u0441\\u0441\\u044b\\u043b\\u043a\\u0430\"\n        },\n        \"type\": \"nav_menu_item\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2019-04-09 10:27:15\"\n    },\n    \"nav_menu_item[-7726415954755744000]\": {\n        \"value\": {\n            \"object_id\": 0,\n            \"object\": \"custom\",\n            \"menu_item_parent\": 0,\n            \"position\": 3,\n            \"type\": \"custom\",\n            \"title\": \"Expertise\",\n            \"url\": \"#\",\n            \"target\": \"\",\n            \"attr_title\": \"\",\n            \"description\": \"\",\n            \"classes\": \"\",\n            \"xfn\": \"\",\n            \"status\": \"publish\",\n            \"original_title\": \"Expertise\",\n            \"nav_menu_term_id\": -5664243205556818000,\n            \"_invalid\": false,\n            \"type_label\": \"\\u041f\\u0440\\u043e\\u0438\\u0437\\u0432\\u043e\\u043b\\u044c\\u043d\\u0430\\u044f \\u0441\\u0441\\u044b\\u043b\\u043a\\u0430\"\n        },\n        \"type\": \"nav_menu_item\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2019-04-09 10:27:41\"\n    },\n    \"nav_menu_item[-5139832096184822000]\": {\n        \"value\": {\n            \"object_id\": 0,\n            \"object\": \"custom\",\n            \"menu_item_parent\": 0,\n            \"position\": 4,\n            \"type\": \"custom\",\n            \"title\": \"Teams\",\n            \"url\": \"#\",\n            \"target\": \"\",\n            \"attr_title\": \"\",\n            \"description\": \"\",\n            \"classes\": \"\",\n            \"xfn\": \"\",\n            \"status\": \"publish\",\n            \"original_title\": \"Teams\",\n            \"nav_menu_term_id\": -5664243205556818000,\n            \"_invalid\": false,\n            \"type_label\": \"\\u041f\\u0440\\u043e\\u0438\\u0437\\u0432\\u043e\\u043b\\u044c\\u043d\\u0430\\u044f \\u0441\\u0441\\u044b\\u043b\\u043a\\u0430\"\n        },\n        \"type\": \"nav_menu_item\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2019-04-09 10:27:54\"\n    },\n    \"nav_menu_item[-1042630885527150600]\": {\n        \"value\": {\n            \"object_id\": 0,\n            \"object\": \"custom\",\n            \"menu_item_parent\": 0,\n            \"position\": 5,\n            \"type\": \"custom\",\n            \"title\": \"Works\",\n            \"url\": \"#\",\n            \"target\": \"\",\n            \"attr_title\": \"\",\n            \"description\": \"\",\n            \"classes\": \"\",\n            \"xfn\": \"\",\n            \"status\": \"publish\",\n            \"original_title\": \"Works\",\n            \"nav_menu_term_id\": -5664243205556818000,\n            \"_invalid\": false,\n            \"type_label\": \"\\u041f\\u0440\\u043e\\u0438\\u0437\\u0432\\u043e\\u043b\\u044c\\u043d\\u0430\\u044f \\u0441\\u0441\\u044b\\u043b\\u043a\\u0430\"\n        },\n        \"type\": \"nav_menu_item\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2019-04-09 10:28:03\"\n    },\n    \"nav_menu_item[-337630999924475900]\": {\n        \"value\": {\n            \"object_id\": 0,\n            \"object\": \"custom\",\n            \"menu_item_parent\": 0,\n            \"position\": 6,\n            \"type\": \"custom\",\n            \"title\": \"People say\",\n            \"url\": \"#\",\n            \"target\": \"\",\n            \"attr_title\": \"\",\n            \"description\": \"\",\n            \"classes\": \"\",\n            \"xfn\": \"\",\n            \"status\": \"publish\",\n            \"original_title\": \"People say\",\n            \"nav_menu_term_id\": -5664243205556818000,\n            \"_invalid\": false,\n            \"type_label\": \"\\u041f\\u0440\\u043e\\u0438\\u0437\\u0432\\u043e\\u043b\\u044c\\u043d\\u0430\\u044f \\u0441\\u0441\\u044b\\u043b\\u043a\\u0430\"\n        },\n        \"type\": \"nav_menu_item\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2019-04-09 10:28:18\"\n    },\n    \"nav_menu_item[-5239233949743473000]\": {\n        \"value\": {\n            \"object_id\": 0,\n            \"object\": \"custom\",\n            \"menu_item_parent\": 0,\n            \"position\": 7,\n            \"type\": \"custom\",\n            \"title\": \"Contact\",\n            \"url\": \"#\",\n            \"target\": \"\",\n            \"attr_title\": \"\",\n            \"description\": \"\",\n            \"classes\": \"\",\n            \"xfn\": \"\",\n            \"status\": \"publish\",\n            \"original_title\": \"Contact\",\n            \"nav_menu_term_id\": -5664243205556818000,\n            \"_invalid\": false,\n            \"type_label\": \"\\u041f\\u0440\\u043e\\u0438\\u0437\\u0432\\u043e\\u043b\\u044c\\u043d\\u0430\\u044f \\u0441\\u0441\\u044b\\u043b\\u043a\\u0430\"\n        },\n        \"type\": \"nav_menu_item\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2019-04-09 10:29:18\"\n    },\n    \"nav_menu_item[-2992474590771345400]\": {\n        \"value\": {\n            \"object_id\": 6,\n            \"object\": \"page\",\n            \"menu_item_parent\": 0,\n            \"position\": 1,\n            \"type\": \"post_type\",\n            \"title\": \"Home\",\n            \"url\": \"http://localhost:8888/tajam/\",\n            \"target\": \"\",\n            \"attr_title\": \"\",\n            \"description\": \"\",\n            \"classes\": \"\",\n            \"xfn\": \"\",\n            \"status\": \"publish\",\n            \"original_title\": \"Home\",\n            \"nav_menu_term_id\": -5664243205556818000,\n            \"_invalid\": false,\n            \"type_label\": \"\\u0421\\u0442\\u0440\\u0430\\u043d\\u0438\\u0446\\u0430\"\n        },\n        \"type\": \"nav_menu_item\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2019-04-09 10:29:18\"\n    }\n}', '', '', 'trash', 'closed', 'closed', '', '4947d89c-3c84-406a-bc0a-7721caf92434', '', '', '2019-04-09 13:29:19', '2019-04-09 10:29:19', '', 0, 'http://localhost:8888/tajam/?p=11', 0, 'customize_changeset', '', 0),
(12, 1, '2019-04-09 13:29:19', '2019-04-09 10:29:19', '', 'About', '', 'publish', 'closed', 'closed', '', 'about', '', '', '2019-04-09 13:29:19', '2019-04-09 10:29:19', '', 0, 'http://localhost:8888/tajam/2019/04/09/about/', 2, 'nav_menu_item', '', 0),
(13, 1, '2019-04-09 13:29:19', '2019-04-09 10:29:19', '', 'Expertise', '', 'publish', 'closed', 'closed', '', 'expertise', '', '', '2019-04-09 13:29:19', '2019-04-09 10:29:19', '', 0, 'http://localhost:8888/tajam/2019/04/09/expertise/', 3, 'nav_menu_item', '', 0),
(14, 1, '2019-04-09 13:29:19', '2019-04-09 10:29:19', '', 'Teams', '', 'publish', 'closed', 'closed', '', 'teams', '', '', '2019-04-09 13:29:19', '2019-04-09 10:29:19', '', 0, 'http://localhost:8888/tajam/2019/04/09/teams/', 4, 'nav_menu_item', '', 0),
(15, 1, '2019-04-09 13:29:19', '2019-04-09 10:29:19', '', 'Works', '', 'publish', 'closed', 'closed', '', 'works', '', '', '2019-04-09 13:29:19', '2019-04-09 10:29:19', '', 0, 'http://localhost:8888/tajam/2019/04/09/works/', 5, 'nav_menu_item', '', 0),
(16, 1, '2019-04-09 13:29:19', '2019-04-09 10:29:19', '', 'People say', '', 'publish', 'closed', 'closed', '', 'people-say', '', '', '2019-04-09 13:29:19', '2019-04-09 10:29:19', '', 0, 'http://localhost:8888/tajam/2019/04/09/people-say/', 6, 'nav_menu_item', '', 0),
(17, 1, '2019-04-09 13:29:19', '2019-04-09 10:29:19', '', 'Contact', '', 'publish', 'closed', 'closed', '', 'contact', '', '', '2019-04-09 13:29:19', '2019-04-09 10:29:19', '', 0, 'http://localhost:8888/tajam/2019/04/09/contact/', 7, 'nav_menu_item', '', 0),
(18, 1, '2019-04-09 13:29:19', '2019-04-09 10:29:19', ' ', '', '', 'publish', 'closed', 'closed', '', '18', '', '', '2019-04-09 13:29:19', '2019-04-09 10:29:19', '', 0, 'http://localhost:8888/tajam/2019/04/09/18/', 1, 'nav_menu_item', '', 0),
(19, 1, '2019-04-09 13:56:37', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2019-04-09 13:56:37', '0000-00-00 00:00:00', '', 0, 'http://localhost:8888/tajam/?post_type=acf-field-group&p=19', 0, 'acf-field-group', '', 0),
(20, 1, '2019-04-09 14:09:21', '2019-04-09 11:09:21', 'a:7:{s:8:\"location\";a:1:{i:0;a:1:{i:0;a:3:{s:5:\"param\";s:13:\"page_template\";s:8:\"operator\";s:2:\"==\";s:5:\"value\";s:18:\"templates/home.php\";}}}s:8:\"position\";s:6:\"normal\";s:5:\"style\";s:7:\"default\";s:15:\"label_placement\";s:3:\"top\";s:21:\"instruction_placement\";s:5:\"label\";s:14:\"hide_on_screen\";s:0:\"\";s:11:\"description\";s:0:\"\";}', 'Home page', 'home-page', 'publish', 'closed', 'closed', '', 'group_5cac7ca3d282d', '', '', '2019-04-10 14:23:38', '2019-04-10 11:23:38', '', 0, 'http://localhost:8888/tajam/?post_type=acf-field-group&#038;p=20', 0, 'acf-field-group', '', 0),
(21, 1, '2019-04-09 14:09:21', '2019-04-09 11:09:21', 'a:7:{s:4:\"type\";s:5:\"group\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:6:\"layout\";s:5:\"block\";s:10:\"sub_fields\";a:0:{}}', 'Banner', 'home_banner', 'publish', 'closed', 'closed', '', 'field_5cac7caea8c52', '', '', '2019-04-09 14:09:21', '2019-04-09 11:09:21', '', 20, 'http://localhost:8888/tajam/?post_type=acf-field&p=21', 0, 'acf-field', '', 0),
(22, 1, '2019-04-09 14:09:21', '2019-04-09 11:09:21', 'a:15:{s:4:\"type\";s:5:\"image\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:1;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"return_format\";s:3:\"url\";s:12:\"preview_size\";s:4:\"full\";s:7:\"library\";s:3:\"all\";s:9:\"min_width\";s:0:\"\";s:10:\"min_height\";s:0:\"\";s:8:\"min_size\";s:0:\"\";s:9:\"max_width\";s:0:\"\";s:10:\"max_height\";s:0:\"\";s:8:\"max_size\";s:0:\"\";s:10:\"mime_types\";s:0:\"\";}', 'Banner image', 'home_banner_image', 'publish', 'closed', 'closed', '', 'field_5cac7ce9a8c53', '', '', '2019-04-09 14:09:21', '2019-04-09 11:09:21', '', 21, 'http://localhost:8888/tajam/?post_type=acf-field&p=22', 0, 'acf-field', '', 0),
(23, 1, '2019-04-09 14:09:21', '2019-04-09 11:09:21', 'a:10:{s:4:\"type\";s:8:\"repeater\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:1;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:9:\"collapsed\";s:0:\"\";s:3:\"min\";s:0:\"\";s:3:\"max\";s:0:\"\";s:6:\"layout\";s:5:\"table\";s:12:\"button_label\";s:0:\"\";}', 'Banner slides', 'home_banner_slides', 'publish', 'closed', 'closed', '', 'field_5cac7d05a8c54', '', '', '2019-04-09 14:09:21', '2019-04-09 11:09:21', '', 21, 'http://localhost:8888/tajam/?post_type=acf-field&p=23', 1, 'acf-field', '', 0),
(24, 1, '2019-04-09 14:09:21', '2019-04-09 11:09:21', 'a:10:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:1;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}', 'Slide title', 'slide_title', 'publish', 'closed', 'closed', '', 'field_5cac7d27a8c55', '', '', '2019-04-09 14:09:21', '2019-04-09 11:09:21', '', 23, 'http://localhost:8888/tajam/?post_type=acf-field&p=24', 0, 'acf-field', '', 0),
(25, 1, '2019-04-09 14:09:21', '2019-04-09 11:09:21', 'a:10:{s:4:\"type\";s:8:\"textarea\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:1;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";s:4:\"rows\";s:0:\"\";s:9:\"new_lines\";s:0:\"\";}', 'Slide text', 'slide_text', 'publish', 'closed', 'closed', '', 'field_5cac7d3da8c56', '', '', '2019-04-09 14:09:21', '2019-04-09 11:09:21', '', 23, 'http://localhost:8888/tajam/?post_type=acf-field&p=25', 1, 'acf-field', '', 0),
(26, 1, '2019-04-09 14:09:21', '2019-04-09 11:09:21', 'a:6:{s:4:\"type\";s:4:\"link\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"return_format\";s:3:\"url\";}', 'Slide link', 'slide_link', 'publish', 'closed', 'closed', '', 'field_5cac7d4ca8c57', '', '', '2019-04-09 14:09:21', '2019-04-09 11:09:21', '', 23, 'http://localhost:8888/tajam/?post_type=acf-field&p=26', 2, 'acf-field', '', 0),
(27, 1, '2019-04-09 14:10:54', '2019-04-09 11:10:54', '', 'banner_image', '', 'inherit', 'open', 'closed', '', 'banner_image', '', '', '2019-04-09 14:10:54', '2019-04-09 11:10:54', '', 6, 'http://localhost:8888/tajam/wp-content/uploads/2019/04/banner_image.png', 0, 'attachment', 'image/png', 0),
(28, 1, '2019-04-09 14:11:58', '2019-04-09 11:11:58', '', 'Home', '', 'inherit', 'closed', 'closed', '', '6-revision-v1', '', '', '2019-04-09 14:11:58', '2019-04-09 11:11:58', '', 6, 'http://localhost:8888/tajam/2019/04/09/6-revision-v1/', 0, 'revision', '', 0),
(29, 1, '2019-04-09 14:46:18', '2019-04-09 11:46:18', '', 'Home', '', 'inherit', 'closed', 'closed', '', '6-revision-v1', '', '', '2019-04-09 14:46:18', '2019-04-09 11:46:18', '', 6, 'http://localhost:8888/tajam/2019/04/09/6-revision-v1/', 0, 'revision', '', 0),
(30, 1, '2019-04-09 21:08:00', '2019-04-09 18:08:00', 'a:7:{s:4:\"type\";s:5:\"group\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:6:\"layout\";s:5:\"block\";s:10:\"sub_fields\";a:0:{}}', 'Story', 'story', 'publish', 'closed', 'closed', '', 'field_5cacdf3200de0', '', '', '2019-04-09 21:08:00', '2019-04-09 18:08:00', '', 20, 'http://localhost:8888/tajam/?post_type=acf-field&p=30', 1, 'acf-field', '', 0),
(31, 1, '2019-04-09 21:08:00', '2019-04-09 18:08:00', 'a:15:{s:4:\"type\";s:5:\"image\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:1;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"return_format\";s:3:\"url\";s:12:\"preview_size\";s:4:\"full\";s:7:\"library\";s:3:\"all\";s:9:\"min_width\";s:0:\"\";s:10:\"min_height\";s:0:\"\";s:8:\"min_size\";s:0:\"\";s:9:\"max_width\";s:0:\"\";s:10:\"max_height\";s:0:\"\";s:8:\"max_size\";s:0:\"\";s:10:\"mime_types\";s:0:\"\";}', 'Image', 'story_image', 'publish', 'closed', 'closed', '', 'field_5cacdf3f00de1', '', '', '2019-04-09 21:08:00', '2019-04-09 18:08:00', '', 30, 'http://localhost:8888/tajam/?post_type=acf-field&p=31', 0, 'acf-field', '', 0),
(32, 1, '2019-04-09 21:08:00', '2019-04-09 18:08:00', 'a:10:{s:4:\"type\";s:7:\"wysiwyg\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:1;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:4:\"tabs\";s:3:\"all\";s:7:\"toolbar\";s:4:\"full\";s:12:\"media_upload\";i:1;s:5:\"delay\";i:0;}', 'Text', 'story_text', 'publish', 'closed', 'closed', '', 'field_5cacdf6b00de2', '', '', '2019-04-10 11:40:23', '2019-04-10 08:40:23', '', 30, 'http://localhost:8888/tajam/?post_type=acf-field&#038;p=32', 2, 'acf-field', '', 0),
(33, 1, '2019-04-09 22:14:46', '2019-04-09 19:14:46', 'a:6:{s:4:\"type\";s:4:\"link\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"return_format\";s:3:\"url\";}', 'Link', 'link', 'publish', 'closed', 'closed', '', 'field_5cacef0cfd4d9', '', '', '2019-04-10 11:40:23', '2019-04-10 08:40:23', '', 30, 'http://localhost:8888/tajam/?post_type=acf-field&#038;p=33', 3, 'acf-field', '', 0),
(34, 1, '2019-04-09 22:19:15', '2019-04-09 19:19:15', 'a:7:{s:4:\"type\";s:5:\"group\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:6:\"layout\";s:5:\"block\";s:10:\"sub_fields\";a:0:{}}', 'Video section', 'video', 'publish', 'closed', 'closed', '', 'field_5cacef294182d', '', '', '2019-04-09 22:19:15', '2019-04-09 19:19:15', '', 20, 'http://localhost:8888/tajam/?post_type=acf-field&p=34', 2, 'acf-field', '', 0),
(35, 1, '2019-04-09 22:19:15', '2019-04-09 19:19:15', 'a:10:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:1;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}', 'Text', 'video_text', 'publish', 'closed', 'closed', '', 'field_5cacef454182e', '', '', '2019-04-09 22:19:15', '2019-04-09 19:19:15', '', 34, 'http://localhost:8888/tajam/?post_type=acf-field&p=35', 0, 'acf-field', '', 0),
(36, 1, '2019-04-09 22:19:15', '2019-04-09 19:19:15', 'a:10:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:1;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:11:\"5lWkZ-JaEOc\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}', 'YouTube video ID', 'video_id', 'publish', 'closed', 'closed', '', 'field_5cacef704182f', '', '', '2019-04-10 12:19:55', '2019-04-10 09:19:55', '', 34, 'http://localhost:8888/tajam/?post_type=acf-field&#038;p=36', 2, 'acf-field', '', 0),
(37, 1, '2019-04-09 22:23:45', '2019-04-09 19:23:45', 'a:7:{s:4:\"type\";s:5:\"group\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:6:\"layout\";s:5:\"block\";s:10:\"sub_fields\";a:0:{}}', 'Expertise section', 'exp', 'publish', 'closed', 'closed', '', 'field_5cacf082b44ec', '', '', '2019-04-09 22:23:45', '2019-04-09 19:23:45', '', 20, 'http://localhost:8888/tajam/?post_type=acf-field&p=37', 3, 'acf-field', '', 0),
(38, 1, '2019-04-09 22:23:45', '2019-04-09 19:23:45', 'a:10:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:1;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}', 'Title', 'exp_title', 'publish', 'closed', 'closed', '', 'field_5cacf097b44ed', '', '', '2019-04-09 22:23:45', '2019-04-09 19:23:45', '', 37, 'http://localhost:8888/tajam/?post_type=acf-field&p=38', 0, 'acf-field', '', 0),
(39, 1, '2019-04-09 22:23:45', '2019-04-09 19:23:45', 'a:10:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}', 'Subtitle', 'exp_subtitle', 'publish', 'closed', 'closed', '', 'field_5cacf0ceb44ee', '', '', '2019-04-09 22:23:45', '2019-04-09 19:23:45', '', 37, 'http://localhost:8888/tajam/?post_type=acf-field&p=39', 1, 'acf-field', '', 0),
(40, 1, '2019-04-09 22:23:45', '2019-04-09 19:23:45', 'a:10:{s:4:\"type\";s:8:\"repeater\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:1;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:9:\"collapsed\";s:0:\"\";s:3:\"min\";i:6;s:3:\"max\";i:6;s:6:\"layout\";s:5:\"table\";s:12:\"button_label\";s:0:\"\";}', 'Items', 'exp_items', 'publish', 'closed', 'closed', '', 'field_5cacf0deb44ef', '', '', '2019-04-10 14:23:38', '2019-04-10 11:23:38', '', 37, 'http://localhost:8888/tajam/?post_type=acf-field&#038;p=40', 2, 'acf-field', '', 0),
(41, 1, '2019-04-09 22:23:45', '2019-04-09 19:23:45', 'a:15:{s:4:\"type\";s:5:\"image\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:1;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"return_format\";s:3:\"url\";s:12:\"preview_size\";s:4:\"full\";s:7:\"library\";s:3:\"all\";s:9:\"min_width\";s:0:\"\";s:10:\"min_height\";s:0:\"\";s:8:\"min_size\";s:0:\"\";s:9:\"max_width\";s:0:\"\";s:10:\"max_height\";s:0:\"\";s:8:\"max_size\";s:0:\"\";s:10:\"mime_types\";s:0:\"\";}', 'Icon', 'e_icon', 'publish', 'closed', 'closed', '', 'field_5cacf0ffb44f0', '', '', '2019-04-09 22:23:45', '2019-04-09 19:23:45', '', 40, 'http://localhost:8888/tajam/?post_type=acf-field&p=41', 0, 'acf-field', '', 0),
(42, 1, '2019-04-09 22:23:45', '2019-04-09 19:23:45', 'a:10:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:1;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}', 'Title', 'e_title', 'publish', 'closed', 'closed', '', 'field_5cacf11eb44f1', '', '', '2019-04-09 22:23:45', '2019-04-09 19:23:45', '', 40, 'http://localhost:8888/tajam/?post_type=acf-field&p=42', 1, 'acf-field', '', 0),
(43, 1, '2019-04-09 22:23:45', '2019-04-09 19:23:45', 'a:10:{s:4:\"type\";s:8:\"textarea\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:1;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";s:4:\"rows\";s:0:\"\";s:9:\"new_lines\";s:0:\"\";}', 'Text', 'e_text', 'publish', 'closed', 'closed', '', 'field_5cacf12cb44f2', '', '', '2019-04-09 22:23:45', '2019-04-09 19:23:45', '', 40, 'http://localhost:8888/tajam/?post_type=acf-field&p=43', 2, 'acf-field', '', 0),
(44, 1, '2019-04-10 11:22:49', '2019-04-10 08:22:49', '', 'imgg', '', 'inherit', 'open', 'closed', '', 'imgg', '', '', '2019-04-10 11:22:49', '2019-04-10 08:22:49', '', 6, 'http://localhost:8888/tajam/wp-content/uploads/2019/04/imgg.png', 0, 'attachment', 'image/png', 0),
(45, 1, '2019-04-10 11:26:24', '2019-04-10 08:26:24', '', 'ic1', '', 'inherit', 'open', 'closed', '', 'ic1', '', '', '2019-04-10 11:26:24', '2019-04-10 08:26:24', '', 6, 'http://localhost:8888/tajam/wp-content/uploads/2019/04/ic1.png', 0, 'attachment', 'image/png', 0),
(46, 1, '2019-04-10 11:26:49', '2019-04-10 08:26:49', '', 'Home', '', 'inherit', 'closed', 'closed', '', '6-revision-v1', '', '', '2019-04-10 11:26:49', '2019-04-10 08:26:49', '', 6, 'http://localhost:8888/tajam/2019/04/10/6-revision-v1/', 0, 'revision', '', 0),
(47, 1, '2019-04-10 11:28:12', '2019-04-10 08:28:12', '', 'Home', '', 'inherit', 'closed', 'closed', '', '6-revision-v1', '', '', '2019-04-10 11:28:12', '2019-04-10 08:28:12', '', 6, 'http://localhost:8888/tajam/2019/04/10/6-revision-v1/', 0, 'revision', '', 0),
(48, 1, '2019-04-10 11:40:23', '2019-04-10 08:40:23', 'a:10:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:1;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:9:\"Our story\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}', 'Title', 'story_title', 'publish', 'closed', 'closed', '', 'field_5cadabdc2e2ef', '', '', '2019-04-10 11:40:23', '2019-04-10 08:40:23', '', 30, 'http://localhost:8888/tajam/?post_type=acf-field&p=48', 1, 'acf-field', '', 0),
(49, 1, '2019-04-10 12:19:55', '2019-04-10 09:19:55', 'a:15:{s:4:\"type\";s:5:\"image\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:1;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"return_format\";s:3:\"url\";s:12:\"preview_size\";s:4:\"full\";s:7:\"library\";s:3:\"all\";s:9:\"min_width\";s:0:\"\";s:10:\"min_height\";s:0:\"\";s:8:\"min_size\";s:0:\"\";s:9:\"max_width\";s:0:\"\";s:10:\"max_height\";s:0:\"\";s:8:\"max_size\";s:0:\"\";s:10:\"mime_types\";s:0:\"\";}', 'Section background image', 'video_image', 'publish', 'closed', 'closed', '', 'field_5cadb5178368a', '', '', '2019-04-10 12:19:55', '2019-04-10 09:19:55', '', 34, 'http://localhost:8888/tajam/?post_type=acf-field&p=49', 1, 'acf-field', '', 0),
(50, 1, '2019-04-10 12:22:47', '2019-04-10 09:22:47', '', 'bg_i', '', 'inherit', 'open', 'closed', '', 'bg_i', '', '', '2019-04-10 12:22:47', '2019-04-10 09:22:47', '', 6, 'http://localhost:8888/tajam/wp-content/uploads/2019/04/bg_i.png', 0, 'attachment', 'image/png', 0),
(51, 1, '2019-04-10 12:23:05', '2019-04-10 09:23:05', '', 'Home', '', 'inherit', 'closed', 'closed', '', '6-revision-v1', '', '', '2019-04-10 12:23:05', '2019-04-10 09:23:05', '', 6, 'http://localhost:8888/tajam/2019/04/10/6-revision-v1/', 0, 'revision', '', 0),
(52, 1, '2019-04-10 13:47:06', '2019-04-10 10:47:06', '', 'ic_2', '', 'inherit', 'open', 'closed', '', 'ic_2', '', '', '2019-04-10 13:47:06', '2019-04-10 10:47:06', '', 6, 'http://localhost:8888/tajam/wp-content/uploads/2019/04/ic_2.png', 0, 'attachment', 'image/png', 0),
(53, 1, '2019-04-10 13:47:32', '2019-04-10 10:47:32', '', 'ic_3', '', 'inherit', 'open', 'closed', '', 'ic_3', '', '', '2019-04-10 13:47:32', '2019-04-10 10:47:32', '', 6, 'http://localhost:8888/tajam/wp-content/uploads/2019/04/ic_3.png', 0, 'attachment', 'image/png', 0),
(54, 1, '2019-04-10 13:47:33', '2019-04-10 10:47:33', '', 'ic_4', '', 'inherit', 'open', 'closed', '', 'ic_4', '', '', '2019-04-10 13:47:33', '2019-04-10 10:47:33', '', 6, 'http://localhost:8888/tajam/wp-content/uploads/2019/04/ic_4.png', 0, 'attachment', 'image/png', 0),
(55, 1, '2019-04-10 13:47:33', '2019-04-10 10:47:33', '', 'ic_5', '', 'inherit', 'open', 'closed', '', 'ic_5', '', '', '2019-04-10 13:47:33', '2019-04-10 10:47:33', '', 6, 'http://localhost:8888/tajam/wp-content/uploads/2019/04/ic_5.png', 0, 'attachment', 'image/png', 0),
(56, 1, '2019-04-10 13:47:34', '2019-04-10 10:47:34', '', 'ic_6', '', 'inherit', 'open', 'closed', '', 'ic_6', '', '', '2019-04-10 13:47:34', '2019-04-10 10:47:34', '', 6, 'http://localhost:8888/tajam/wp-content/uploads/2019/04/ic_6.png', 0, 'attachment', 'image/png', 0),
(57, 1, '2019-04-10 13:48:52', '2019-04-10 10:48:52', '', 'Home', '', 'inherit', 'closed', 'closed', '', '6-revision-v1', '', '', '2019-04-10 13:48:52', '2019-04-10 10:48:52', '', 6, 'http://localhost:8888/tajam/2019/04/10/6-revision-v1/', 0, 'revision', '', 0),
(58, 1, '2019-04-10 14:23:56', '2019-04-10 11:23:56', '<!-- wp:paragraph -->\n<p>Это пример страницы. От записей в блоге она отличается тем, что остаётся на одном месте и отображается в меню сайта (в большинстве тем). На странице &laquo;Детали&raquo; владельцы сайтов обычно рассказывают о себе потенциальным посетителям. Например, так:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:quote -->\n<blockquote class=\"wp-block-quote\"><p>Привет! Днём я курьер, а вечером &#8212; подающий надежды актёр. Это мой блог. Я живу в Ростове-на-Дону, люблю своего пса Джека и пинаколаду. (И ещё попадать под дождь.)</p></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:paragraph -->\n<p>...или так:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:quote -->\n<blockquote class=\"wp-block-quote\"><p>Компания &laquo;Штучки XYZ&raquo; была основана в 1971 году и с тех пор производит качественные штучки. Компания находится в Готэм-сити, имеет штат из более чем 2000 сотрудников и приносит много пользы жителям Готэма.</p></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:paragraph -->\n<p>Перейдите <a href=\"http://localhost:8888/tajam/wp-admin/\">в консоль</a>, чтобы удалить эту страницу и создать новые. Успехов!</p>\n<!-- /wp:paragraph -->', 'Пример страницы', '', 'inherit', 'closed', 'closed', '', '2-revision-v1', '', '', '2019-04-10 14:23:56', '2019-04-10 11:23:56', '', 2, 'http://localhost:8888/tajam/2019/04/10/2-revision-v1/', 0, 'revision', '', 0),
(59, 1, '2019-04-10 15:05:52', '2019-04-10 12:05:52', '{\n    \"tajam::nav_menu_locations[footer]\": {\n        \"value\": -7605418449697669000,\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2019-04-10 12:03:41\"\n    },\n    \"nav_menu[-7605418449697669000]\": {\n        \"value\": {\n            \"name\": \"Footer menu\",\n            \"description\": \"\",\n            \"parent\": 0,\n            \"auto_add\": false\n        },\n        \"type\": \"nav_menu\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2019-04-10 12:03:41\"\n    },\n    \"nav_menu_item[-1172606045650360300]\": {\n        \"value\": {\n            \"object_id\": 0,\n            \"object\": \"custom\",\n            \"menu_item_parent\": 0,\n            \"position\": 1,\n            \"type\": \"custom\",\n            \"title\": \"Help\",\n            \"url\": \"#\",\n            \"target\": \"\",\n            \"attr_title\": \"\",\n            \"description\": \"\",\n            \"classes\": \"\",\n            \"xfn\": \"\",\n            \"status\": \"publish\",\n            \"original_title\": \"Help\",\n            \"nav_menu_term_id\": -7605418449697669000,\n            \"_invalid\": false,\n            \"type_label\": \"Custom Link\"\n        },\n        \"type\": \"nav_menu_item\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2019-04-10 12:03:55\"\n    },\n    \"nav_menu_item[-8130962910293393000]\": {\n        \"value\": {\n            \"object_id\": 0,\n            \"object\": \"custom\",\n            \"menu_item_parent\": 0,\n            \"position\": 2,\n            \"type\": \"custom\",\n            \"title\": \"Terms & Conditions\",\n            \"url\": \"#\",\n            \"target\": \"\",\n            \"attr_title\": \"\",\n            \"description\": \"\",\n            \"classes\": \"\",\n            \"xfn\": \"\",\n            \"status\": \"publish\",\n            \"original_title\": \"Terms & Conditions\",\n            \"nav_menu_term_id\": -7605418449697669000,\n            \"_invalid\": false,\n            \"type_label\": \"Custom Link\"\n        },\n        \"type\": \"nav_menu_item\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2019-04-10 12:05:00\"\n    },\n    \"nav_menu_item[-6648744037209668000]\": {\n        \"value\": {\n            \"object_id\": 0,\n            \"object\": \"custom\",\n            \"menu_item_parent\": 0,\n            \"position\": 3,\n            \"type\": \"custom\",\n            \"title\": \"Privacy\",\n            \"url\": \"#\",\n            \"target\": \"\",\n            \"attr_title\": \"\",\n            \"description\": \"\",\n            \"classes\": \"\",\n            \"xfn\": \"\",\n            \"status\": \"publish\",\n            \"original_title\": \"Privacy\",\n            \"nav_menu_term_id\": -7605418449697669000,\n            \"_invalid\": false,\n            \"type_label\": \"Custom Link\"\n        },\n        \"type\": \"nav_menu_item\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2019-04-10 12:05:52\"\n    }\n}', '', '', 'trash', 'closed', 'closed', '', '6c4132b8-1d8e-4988-ac54-70b3c915dcf6', '', '', '2019-04-10 15:05:52', '2019-04-10 12:05:52', '', 0, 'http://localhost:8888/tajam/?p=59', 0, 'customize_changeset', '', 0),
(60, 1, '2019-04-10 15:05:52', '2019-04-10 12:05:52', '', 'Help', '', 'publish', 'closed', 'closed', '', 'help', '', '', '2019-04-10 15:05:52', '2019-04-10 12:05:52', '', 0, 'http://localhost:8888/tajam/2019/04/10/help/', 1, 'nav_menu_item', '', 0),
(61, 1, '2019-04-10 15:05:52', '2019-04-10 12:05:52', '', 'Terms & Condition', '', 'publish', 'closed', 'closed', '', 'terms-conditions', '', '', '2019-04-11 12:41:42', '2019-04-11 09:41:42', '', 0, 'http://localhost:8888/tajam/2019/04/10/terms-conditions/', 2, 'nav_menu_item', '', 0),
(62, 1, '2019-04-10 15:05:52', '2019-04-10 12:05:52', '', 'Privacy', '', 'publish', 'closed', 'closed', '', 'privacy', '', '', '2019-04-10 15:05:52', '2019-04-10 12:05:52', '', 0, 'http://localhost:8888/tajam/2019/04/10/privacy/', 3, 'nav_menu_item', '', 0),
(63, 1, '2019-04-10 15:23:10', '2019-04-10 12:23:10', '{\n    \"tajam::logo_image_footer\": {\n        \"value\": \"http://localhost:8888/tajam/wp-content/uploads/2019/04/logo.png\",\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2019-04-10 12:23:10\"\n    }\n}', '', '', 'trash', 'closed', 'closed', '', '36eb4dae-2201-44da-991a-03ef5db3549d', '', '', '2019-04-10 15:23:10', '2019-04-10 12:23:10', '', 0, 'http://localhost:8888/tajam/2019/04/10/36eb4dae-2201-44da-991a-03ef5db3549d/', 0, 'customize_changeset', '', 0),
(64, 1, '2019-04-10 15:39:44', '2019-04-10 12:39:44', '{\n    \"tajam::footer_social_facebook\": {\n        \"value\": \"#\",\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2019-04-10 12:39:13\"\n    },\n    \"tajam::footer_social_twitter\": {\n        \"value\": \"#\",\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2019-04-10 12:39:13\"\n    },\n    \"tajam::footer_social_dribbble\": {\n        \"value\": \"#\",\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2019-04-10 12:39:13\"\n    },\n    \"tajam::footer_social_instagram\": {\n        \"value\": \"#\",\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2019-04-10 12:39:13\"\n    },\n    \"tajam::footer_social_google\": {\n        \"value\": \"#\",\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2019-04-10 12:39:13\"\n    },\n    \"tajam::footer_social_youtube\": {\n        \"value\": \"#\",\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2019-04-10 12:39:13\"\n    },\n    \"tajam::footer_tel\": {\n        \"value\": \"(+62) 21-2224 3333\",\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2019-04-10 12:39:26\"\n    },\n    \"tajam::footer_location\": {\n        \"value\": \"Ruko cucruk, Jl. Radio luar dalem jos No.12 - 13, Kalideres - Jakarta Barat 11480 - Indonesia\",\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2019-04-10 12:39:36\"\n    },\n    \"tajam::footer_text\": {\n        \"value\": \"lorem quis bibendum auctor, nisi elit consequat ipsum, nec sagittis sem nibh elit. Duis sed odio sit amet auctror a ornare odio non mauris vitae erat in elit\",\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2019-04-10 12:39:44\"\n    }\n}', '', '', 'trash', 'closed', 'closed', '', 'f1a28c17-9585-4212-9f91-cc951cb1b852', '', '', '2019-04-10 15:39:44', '2019-04-10 12:39:44', '', 0, 'http://localhost:8888/tajam/?p=64', 0, 'customize_changeset', '', 0),
(65, 1, '2019-04-11 12:41:42', '2019-04-11 09:41:42', '{\n    \"nav_menu_item[61]\": {\n        \"value\": {\n            \"menu_item_parent\": 0,\n            \"object_id\": 61,\n            \"object\": \"custom\",\n            \"type\": \"custom\",\n            \"type_label\": \"Custom Link\",\n            \"title\": \"Terms & Condition\",\n            \"url\": \"#\",\n            \"target\": \"\",\n            \"attr_title\": \"\",\n            \"description\": \"\",\n            \"classes\": \"\",\n            \"xfn\": \"\",\n            \"nav_menu_term_id\": 3,\n            \"position\": 2,\n            \"status\": \"publish\",\n            \"original_title\": \"\",\n            \"_invalid\": false\n        },\n        \"type\": \"nav_menu_item\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2019-04-11 09:41:42\"\n    }\n}', '', '', 'trash', 'closed', 'closed', '', '8a018bfc-eb66-4451-9bc1-26bd1620852e', '', '', '2019-04-11 12:41:42', '2019-04-11 09:41:42', '', 0, 'http://localhost:8888/tajam/2019/04/11/8a018bfc-eb66-4451-9bc1-26bd1620852e/', 0, 'customize_changeset', '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `wp_termmeta`
--

CREATE TABLE `wp_termmeta` (
  `meta_id` bigint(20) UNSIGNED NOT NULL,
  `term_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- Table structure for table `wp_terms`
--

CREATE TABLE `wp_terms` (
  `term_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `slug` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Dumping data for table `wp_terms`
--

INSERT INTO `wp_terms` (`term_id`, `name`, `slug`, `term_group`) VALUES
(1, 'Без рубрики', '%d0%b1%d0%b5%d0%b7-%d1%80%d1%83%d0%b1%d1%80%d0%b8%d0%ba%d0%b8', 0),
(2, 'Header menu', 'header-menu', 0),
(3, 'Footer menu', 'footer-menu', 0);

-- --------------------------------------------------------

--
-- Table structure for table `wp_term_relationships`
--

CREATE TABLE `wp_term_relationships` (
  `object_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `term_taxonomy_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `term_order` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Dumping data for table `wp_term_relationships`
--

INSERT INTO `wp_term_relationships` (`object_id`, `term_taxonomy_id`, `term_order`) VALUES
(1, 1, 0),
(12, 2, 0),
(13, 2, 0),
(14, 2, 0),
(15, 2, 0),
(16, 2, 0),
(17, 2, 0),
(18, 2, 0),
(60, 3, 0),
(61, 3, 0),
(62, 3, 0);

-- --------------------------------------------------------

--
-- Table structure for table `wp_term_taxonomy`
--

CREATE TABLE `wp_term_taxonomy` (
  `term_taxonomy_id` bigint(20) UNSIGNED NOT NULL,
  `term_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `taxonomy` varchar(32) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `description` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `parent` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `count` bigint(20) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Dumping data for table `wp_term_taxonomy`
--

INSERT INTO `wp_term_taxonomy` (`term_taxonomy_id`, `term_id`, `taxonomy`, `description`, `parent`, `count`) VALUES
(1, 1, 'category', '', 0, 1),
(2, 2, 'nav_menu', '', 0, 7),
(3, 3, 'nav_menu', '', 0, 3);

-- --------------------------------------------------------

--
-- Table structure for table `wp_usermeta`
--

CREATE TABLE `wp_usermeta` (
  `umeta_id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Dumping data for table `wp_usermeta`
--

INSERT INTO `wp_usermeta` (`umeta_id`, `user_id`, `meta_key`, `meta_value`) VALUES
(1, 1, 'nickname', 'admin'),
(2, 1, 'first_name', ''),
(3, 1, 'last_name', ''),
(4, 1, 'description', ''),
(5, 1, 'rich_editing', 'true'),
(6, 1, 'syntax_highlighting', 'true'),
(7, 1, 'comment_shortcuts', 'false'),
(8, 1, 'admin_color', 'fresh'),
(9, 1, 'use_ssl', '0'),
(10, 1, 'show_admin_bar_front', 'true'),
(11, 1, 'locale', ''),
(12, 1, 'wp_capabilities', 'a:1:{s:13:\"administrator\";b:1;}'),
(13, 1, 'wp_user_level', '10'),
(14, 1, 'dismissed_wp_pointers', 'wp496_privacy'),
(15, 1, 'show_welcome_panel', '1'),
(16, 1, 'session_tokens', 'a:2:{s:64:\"3c37f9c1be0aed81f2d71b8ab1a5ace6512cc50f7e4e3f7c7088ec6e5bc82e69\";a:4:{s:10:\"expiration\";i:1555057334;s:2:\"ip\";s:3:\"::1\";s:2:\"ua\";s:119:\"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/12.0.3 Safari/605.1.15\";s:5:\"login\";i:1554884534;}s:64:\"fcc3d5442625ac5172ba19918eac9f2df8fe0a60baeab8250fe7344f4050c670\";a:4:{s:10:\"expiration\";i:1555148494;s:2:\"ip\";s:3:\"::1\";s:2:\"ua\";s:120:\"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.86 Safari/537.36\";s:5:\"login\";i:1554975694;}}'),
(17, 1, 'wp_dashboard_quick_press_last_post_id', '4'),
(18, 1, 'closedpostboxes_page', 'a:0:{}'),
(19, 1, 'metaboxhidden_page', 'a:4:{i:0;s:10:\"postcustom\";i:1;s:16:\"commentstatusdiv\";i:2;s:7:\"slugdiv\";i:3;s:9:\"authordiv\";}'),
(20, 1, 'wp_user-settings', 'libraryContent=browse&editor=tinymce'),
(21, 1, 'wp_user-settings-time', '1554884805');

-- --------------------------------------------------------

--
-- Table structure for table `wp_users`
--

CREATE TABLE `wp_users` (
  `ID` bigint(20) UNSIGNED NOT NULL,
  `user_login` varchar(60) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_pass` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_nicename` varchar(50) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_email` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_url` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT '0',
  `display_name` varchar(250) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Dumping data for table `wp_users`
--

INSERT INTO `wp_users` (`ID`, `user_login`, `user_pass`, `user_nicename`, `user_email`, `user_url`, `user_registered`, `user_activation_key`, `user_status`, `display_name`) VALUES
(1, 'admin', '$P$BGfnuC0bljpN.YQ4UhR5slVKJk66YS.', 'admin', 'farik4098@gmail.com', '', '2019-04-09 08:42:50', '', 0, 'admin');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `wp_commentmeta`
--
ALTER TABLE `wp_commentmeta`
  ADD PRIMARY KEY (`meta_id`),
  ADD KEY `comment_id` (`comment_id`),
  ADD KEY `meta_key` (`meta_key`(191));

--
-- Indexes for table `wp_comments`
--
ALTER TABLE `wp_comments`
  ADD PRIMARY KEY (`comment_ID`),
  ADD KEY `comment_post_ID` (`comment_post_ID`),
  ADD KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  ADD KEY `comment_date_gmt` (`comment_date_gmt`),
  ADD KEY `comment_parent` (`comment_parent`),
  ADD KEY `comment_author_email` (`comment_author_email`(10));

--
-- Indexes for table `wp_links`
--
ALTER TABLE `wp_links`
  ADD PRIMARY KEY (`link_id`),
  ADD KEY `link_visible` (`link_visible`);

--
-- Indexes for table `wp_options`
--
ALTER TABLE `wp_options`
  ADD PRIMARY KEY (`option_id`),
  ADD UNIQUE KEY `option_name` (`option_name`);

--
-- Indexes for table `wp_postmeta`
--
ALTER TABLE `wp_postmeta`
  ADD PRIMARY KEY (`meta_id`),
  ADD KEY `post_id` (`post_id`),
  ADD KEY `meta_key` (`meta_key`(191));

--
-- Indexes for table `wp_posts`
--
ALTER TABLE `wp_posts`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `post_name` (`post_name`(191)),
  ADD KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  ADD KEY `post_parent` (`post_parent`),
  ADD KEY `post_author` (`post_author`);

--
-- Indexes for table `wp_termmeta`
--
ALTER TABLE `wp_termmeta`
  ADD PRIMARY KEY (`meta_id`),
  ADD KEY `term_id` (`term_id`),
  ADD KEY `meta_key` (`meta_key`(191));

--
-- Indexes for table `wp_terms`
--
ALTER TABLE `wp_terms`
  ADD PRIMARY KEY (`term_id`),
  ADD KEY `slug` (`slug`(191)),
  ADD KEY `name` (`name`(191));

--
-- Indexes for table `wp_term_relationships`
--
ALTER TABLE `wp_term_relationships`
  ADD PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  ADD KEY `term_taxonomy_id` (`term_taxonomy_id`);

--
-- Indexes for table `wp_term_taxonomy`
--
ALTER TABLE `wp_term_taxonomy`
  ADD PRIMARY KEY (`term_taxonomy_id`),
  ADD UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  ADD KEY `taxonomy` (`taxonomy`);

--
-- Indexes for table `wp_usermeta`
--
ALTER TABLE `wp_usermeta`
  ADD PRIMARY KEY (`umeta_id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `meta_key` (`meta_key`(191));

--
-- Indexes for table `wp_users`
--
ALTER TABLE `wp_users`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `user_login_key` (`user_login`),
  ADD KEY `user_nicename` (`user_nicename`),
  ADD KEY `user_email` (`user_email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `wp_commentmeta`
--
ALTER TABLE `wp_commentmeta`
  MODIFY `meta_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `wp_comments`
--
ALTER TABLE `wp_comments`
  MODIFY `comment_ID` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `wp_links`
--
ALTER TABLE `wp_links`
  MODIFY `link_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `wp_options`
--
ALTER TABLE `wp_options`
  MODIFY `option_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=215;
--
-- AUTO_INCREMENT for table `wp_postmeta`
--
ALTER TABLE `wp_postmeta`
  MODIFY `meta_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=533;
--
-- AUTO_INCREMENT for table `wp_posts`
--
ALTER TABLE `wp_posts`
  MODIFY `ID` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=66;
--
-- AUTO_INCREMENT for table `wp_termmeta`
--
ALTER TABLE `wp_termmeta`
  MODIFY `meta_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `wp_terms`
--
ALTER TABLE `wp_terms`
  MODIFY `term_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `wp_term_taxonomy`
--
ALTER TABLE `wp_term_taxonomy`
  MODIFY `term_taxonomy_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `wp_usermeta`
--
ALTER TABLE `wp_usermeta`
  MODIFY `umeta_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;
--
-- AUTO_INCREMENT for table `wp_users`
--
ALTER TABLE `wp_users`
  MODIFY `ID` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
